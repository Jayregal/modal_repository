import { render } from "@testing-library/react";
import LocationDropdown from "Components/Smart-Components/LocationDropdown";
import locationListData from "./mockdata/mockLocation.json";

describe("Test the Location Dropdown Component", () => {
  test("it renders without crashing", () => {
    render(<LocationDropdown dataList={locationListData} />);
  });
});
