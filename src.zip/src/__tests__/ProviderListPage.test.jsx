import { render } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import ProviderListPage from "Components/Templates/DataPages/ProviderListPage";

const RouterWrapper = ({ children }) => <MemoryRouter>{children}</MemoryRouter>;

describe("Test the Contact Information Component", () => {
  test("it renders without crashing", () => {
    render(<ProviderListPage />, {
      wrapper: RouterWrapper,
    });
  });
});
