import { render } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import Home from "Components/Templates/Home/Home";

const RouterWrapper = ({ children }) => <MemoryRouter>{children}</MemoryRouter>;

describe("Test the Home Component", () => {
  test("it renders without crashing", () => {
    render(<Home />, {
      wrapper: RouterWrapper,
    });
  });
});
