import { render, screen, cleanup } from "@testing-library/react";
import Title from "Components/UI/Atoms/Title/Title";
import renderer from "react-test-renderer";

afterEach(cleanup);

describe("Test the Title Component", () => {
  test("renders practice name in the document", () => {
    render(<Title />);
    const linkElement = screen.getByTestId("practiceName");
    expect(linkElement).toBeInTheDocument();
  });

  test("should render the component correctly", () => {
    const tree = renderer.create(<Title />).toJSON();
    expect(tree).toMatchSnapshot();
  });
});
