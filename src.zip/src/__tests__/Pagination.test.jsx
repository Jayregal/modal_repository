import React from "react";
import { render, fireEvent } from "@testing-library/react";
import Pagination from "Components/Templates/ProviderList/Pagination";

describe("Pagination component", () => {
  it("should render the current page and total number of pages", () => {
    const { getByText } = render(
      <Pagination nPages={10} currentPage={5} setCurrentPage={() => {}} />
    );
    expect(getByText("5 / 10 pages")).toBeInTheDocument();
  });

  it("should call the setCurrentPage function with the next page number when the next button is clicked", () => {
    const setCurrentPage = jest.fn();
    const { getByTestId } = render(
      <Pagination nPages={10} currentPage={5} setCurrentPage={setCurrentPage} />
    );
    fireEvent.click(getByTestId("nextpage"));
    expect(setCurrentPage).toHaveBeenCalledWith(6);
  });

  it("should call the setCurrentPage function with the previous page number when the previous button is clicked", () => {
    const setCurrentPage = jest.fn();
    const { getByTestId } = render(
      <Pagination nPages={10} currentPage={5} setCurrentPage={setCurrentPage} />
    );
    fireEvent.click(getByTestId("prevpage"));
    expect(setCurrentPage).toHaveBeenCalledWith(4);
  });

  it("should not call the setCurrentPage function when the current page is 1 and previous button is clicked", () => {
    const setCurrentPage = jest.fn();
    const { getByTestId } = render(
      <Pagination nPages={10} currentPage={1} setCurrentPage={setCurrentPage} />
    );
    fireEvent.click(getByTestId("prevpage"));
    expect(setCurrentPage).not.toHaveBeenCalled();
  });

  it("should not call the setCurrentPage function when the current page is the last page and next button is clicked", () => {
    const setCurrentPage = jest.fn();
    const { getByTestId } = render(
      <Pagination
        nPages={10}
        currentPage={10}
        setCurrentPage={setCurrentPage}
      />
    );
    fireEvent.click(getByTestId("nextpage"));
    expect(setCurrentPage).not.toHaveBeenCalled();
  });
});
