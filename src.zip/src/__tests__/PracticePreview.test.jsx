import { render } from "@testing-library/react";
import PracticePreview from "Components/UI/Molecules/PracticePreview";

describe("Test the Practice Preview Component", () => {
  test("it renders without crashing", () => {
    render(<PracticePreview />);
  });
});
