import { render } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import PracticeInformationPage from "Components/Templates/DataPages/PracticeInformationPage";

const RouterWrapper = ({ children }) => <MemoryRouter>{children}</MemoryRouter>;

describe("Test the Practice Information Page Component", () => {
  test("it renders without crashing", () => {
    render(<PracticeInformationPage />, {
      wrapper: RouterWrapper,
    });
  });
});
