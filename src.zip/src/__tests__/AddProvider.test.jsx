import { render, cleanup, screen, fireEvent } from "@testing-library/react";
import AddProvider from "Components/Templates/ProviderList/AddProvider";
import { MemoryRouter } from "react-router-dom";
import * as yup from "yup";
import { Button } from "react-bootstrap";
import addIcon from "Components/Templates/ProviderList/add-icon.svg";
import providerSummary from "./mockdata/mockProviderSummary.json";

const RouterWrapper = ({ children }) => <MemoryRouter>{children}</MemoryRouter>;

afterEach(cleanup);

describe("Test the Add Provider Component", () => {
  let modalShow;
  let setModalShow;
  beforeEach(() => {
    modalShow = false;
    setModalShow = jest.fn(() => {
      modalShow = true;
    });
  });
  test("it should renders without crashing", () => {
    render(<AddProvider providerSummary={providerSummary} />, {
      wrapper: MemoryRouter,
    });
  });
  test("should show labels in Edit Provider form", () => {
    render(<AddProvider providerSummary={providerSummary} />, {
      wrapper: MemoryRouter,
    });
    const label = screen.getByText(/first name/i);
    expect(label).toBeInTheDocument();
    // expect(getByText(/middle initial/i)).toBeInTheDocument()
  });
  test("Practice location section should include in the document", () => {
    render(<AddProvider providerSummary={providerSummary} />, {
      wrapper: MemoryRouter,
    });
    const locationHeading = screen.getByRole("heading");
    expect(locationHeading).toBeInTheDocument();
  });
  test("render add Location component in the document", () => {
    const { getByText } = render(
      <AddProvider providerSummary={providerSummary} />,
      { wrapper: MemoryRouter }
    );
    const childElement = getByText(
      /please confirm that all information is correct/i
    );
    expect(childElement).toBeTruthy();
  });
  test("test the confirm and save button on the document", () => {
    render(<AddProvider providerSummary={providerSummary} />, {
      wrapper: MemoryRouter,
    });
    const buttonElement = screen.getByRole("button", {
      name: /confirm and save/i,
    });
    console.log("buttons", buttonElement);
    expect(buttonElement).toBeTruthy();
  });

  const validationSchema = yup.object({
    firstName: yup
      .string()
      .max(25, "Too Long!")
      .matches(/^[aA-zZ\s]+$/, "Name cannot contain numbers ")
      .required("First Name is required"),
    middleName: yup
      .string()
      .nullable()
      .max(25, "Too Long!")
      .matches(/^[aA-zZ\s]+$/, "Name cannot contain numbers"),
    lastName: yup
      .string()
      .max(25, "Too Long!")
      .matches(/^[A-Za-z\s'_.-]+$/, "Name cannot contain numbers ")
      .required("Last Name is required"),
    mdofficeId: yup.string().max(25, "Too Long!"),
    npi: yup
      .string()
      .required("NPI is required")
      .min(10, "NPI should be 10 digits")
      .max(10, "NPI should be 10 digits")
      .matches(/^[0-9]+$/, "Must be only digits"),
    preferredEmailAddress: yup
      .string()
      .email("Invalid email format")
      .required("Email required."),
    sentaraEmailAddress: yup.string().email("Invalid email format"),
  });

  test("validates a valid name", async () => {
    await expect(
      validationSchema.validate({
        firstName: "John",
        middleName: "Ling",
        lastName: "King",
        mdofficeId: "AXVANVOO",
        npi: "1234567890",
        preferredEmailAddress: "test@gmail.com",
        sentaraEmailAddress: "test@sentara.com",
      })
    ).resolves.toEqual({
      firstName: "John",
      middleName: "Ling",
      lastName: "King",
      mdofficeId: "AXVANVOO",
      npi: "1234567890",
      preferredEmailAddress: "test@gmail.com",
      sentaraEmailAddress: "test@sentara.com",
    });
  });
  test("fails validation for a name that is too long", async () => {
    await expect(
      validationSchema.validate({
        firstName: "a".repeat(26),
        middleName: "a".repeat(26),
        lastName: "a".repeat(26),
        mdofficeId: "a".repeat(26),
        npi: "1234567890",
        preferredEmailAddress: "test@gmail.com",
        sentaraEmailAddress: "test@sentara.com",
      })
    ).rejects.toThrow("Too Long!");
  });
  test("fails validation for NPI should be 10 digits", async () => {
    await expect(
      validationSchema.validate({
        firstName: "a".repeat(25),
        middleName: "a".repeat(25),
        lastName: "a".repeat(25),
        mdofficeId: "a".repeat(25),
        npi: "a".repeat(11),
        preferredEmailAddress: "test@gmail.com",
        sentaraEmailAddress: "test@sentara.com",
      })
    ).rejects.toThrow("NPI should be 10 digits");
  });
  test("fails validation for NPI should be 10 digits", async () => {
    await expect(
      validationSchema.validate({
        firstName: "a".repeat(25),
        middleName: "a".repeat(25),
        lastName: "a".repeat(25),
        mdofficeId: "a".repeat(25),
        npi: "a".repeat(9),
        preferredEmailAddress: "test@gmail.com",
        sentaraEmailAddress: "test@sentara.com",
      })
    ).rejects.toThrow("NPI should be 10 digits");
  });
  test("fails validation for a name that contains numbers", async () => {
    await expect(
      validationSchema.validate({
        firstName: "John1",
        middleName: "Ling1",
        lastName: "King1",
        npi: "1111111111",
        preferredEmailAddress: "test@gmail.com",
        sentaraEmailAddress: "test@sentara.com",
      })
    ).rejects.toThrow("Name cannot contain numbers");
  });
  test("fails validation for a email format", async () => {
    await expect(
      validationSchema.validate({
        firstName: "John1",
        middleName: "Ling1",
        lastName: "King1",
        npi: "1111111111",
        preferredEmailAddress: "test",
        sentaraEmailAddress: "test",
      })
    ).rejects.toThrow("Invalid email format");
  });
  test("fails validation for a missing value", async () => {
    await expect(
      validationSchema.validate({
        lastName: "King",
        npi: "1234567890",
        preferredEmailAddress: "test@gmail.com",
        sentaraEmailAddress: "test@sentara.com",
      })
    ).rejects.toThrow("First Name is required");
  });
  test("fails validation for a missing value", async () => {
    await expect(
      validationSchema.validate({
        firstName: "John",
        middleName: "Ling",
        npi: "1234567890",
        preferredEmailAddress: "test@gmail.com",
        sentaraEmailAddress: "test@sentara.com",
      })
    ).rejects.toThrow("Last Name is required");
  });
  test("fails validation for a missing value", async () => {
    await expect(
      validationSchema.validate({
        firstName: "John",
        middleName: "Ling",
        lastName: "King",
        preferredEmailAddress: "test@gmail.com",
        sentaraEmailAddress: "test@sentara.com",
      })
    ).rejects.toThrow("NPI is required");
  });
  test("fails validation for a missing value", async () => {
    await expect(
      validationSchema.validate({
        firstName: "John",
        middleName: "Ling",
        lastName: "King",
        sentaraEmailAddress: "test@sentara.com",
      })
    ).rejects.toThrow("Email required.");
  });

  it("should render Add New Provider component correctly", () => {
    render(<AddProvider providerSummary={providerSummary} />, {
      wrapper: MemoryRouter,
    });
    const element = screen.getByRole("heading");
    expect(element).toBeInTheDocument();
  });

  test("renders correct label text", () => {
    const { getByText } = render(
      <AddProvider
        labels={{ TITLE: "Title" }}
        providerSummary={providerSummary}
      />,
      {
        wrapper: MemoryRouter,
      }
    );
    const label = getByText("Title");
    expect(label).toBeInTheDocument();
  });

  test("renders the button with text Add Location", () => {
    const { getByText } = render(
      <Button
        variant="primary"
        onClick={() => setModalShow(true)}
        className="add-location"
      >
        <span>
          <img src={addIcon} alt="add icon" />
        </span>
        Add Location
      </Button>
    );
    const button = getByText("Add Location");
    expect(button).toBeInTheDocument();
  });

  test("modalShow is set to true when button is clicked", () => {
    const { getByText } = render(
      <Button
        variant="primary"
        onClick={() => setModalShow(true)}
        className="add-location"
      >
        <span>
          <img src={addIcon} alt="add icon" />
        </span>
        Add Location
      </Button>
    );
    const button = getByText("Add Location");
    fireEvent.click(button);
    expect(modalShow).toBe(true);
  });

  test("className should be error-field nb-input when formik.touched.firstName and formik.errors.firstName are truthy", () => {
    const formik = {
      touched: { firstName: true },
      errors: { firstName: true },
    };

    const { container } = render(
      <div
        className={
          formik.touched.firstName && formik.errors.firstName
            ? "error-field nb-input"
            : "nb-input"
        }
      />
    );

    expect(container.firstChild).toHaveClass("error-field nb-input");
  });

  test("className should be nb-input when formik.touched.firstName is truthy and formik.errors.firstName is falsy", () => {
    const formik = {
      touched: { firstName: true },
      errors: { firstName: false },
    };

    const { container } = render(
      <div
        className={
          formik.touched.firstName && formik.errors.firstName
            ? "error-field nb-input"
            : "nb-input"
        }
      />
    );
    expect(container.firstChild).toHaveClass("nb-input");
  });

  test("className should be nb-input when formik.touched.firstName is falsy and formik.errors.firstName is truthy", () => {
    const formik = {
      touched: { firstName: false },
      errors: { firstName: true },
    };
    const { container } = render(
      <div
        className={
          formik.touched.firstName && formik.errors.firstName
            ? "error-field nb-input"
            : "nb-input"
        }
      />
    );
    expect(container.firstChild).toHaveClass("nb-input");
  });

  test("className should be error-field nb-input when formik.touched.firstName and formik.errors.firstName are truthy", () => {
    const formik = {
      touched: { firstName: true },
      errors: { firstName: true },
    };

    const { container } = render(
      <div
        className={
          formik.touched.firstName && formik.errors.firstName
            ? "error-field nb-input"
            : "nb-input"
        }
      />
    );

    expect(container.firstChild).toHaveClass("error-field nb-input");
  });

  test("className should be nb-input when formik.touched.firstName is truthy and formik.errors.firstName is falsy", () => {
    const formik = {
      touched: { firstName: true },
      errors: { firstName: false },
    };

    const { container } = render(
      <div
        className={
          formik.touched.firstName && formik.errors.firstName
            ? "error-field nb-input"
            : "nb-input"
        }
      />
    );
    expect(container.firstChild).toHaveClass("nb-input");
  });

  test("className should be nb-input when formik.touched.firstName is falsy and formik.errors.firstName is truthy", () => {
    const formik = {
      touched: { firstName: false },
      errors: { firstName: true },
    };
    const { container } = render(
      <div
        className={
          formik.touched.firstName && formik.errors.firstName
            ? "error-field nb-input"
            : "nb-input"
        }
      />
    );
    expect(container.firstChild).toHaveClass("nb-input");
  });

  it("should display error when first name is not entered", () => {
    const { getByTestId } = render(<AddProvider />, {
      wrapper: RouterWrapper,
    });
    fireEvent.blur(getByTestId("input"));
    expect(getByTestId("providerFirstNameError")).toHaveTextContent(
      "First name is required"
    );
  });

  it("should not display error when first name is entered", () => {
    const { getByTestId, queryByTestId } = render(<AddProvider />, {
      wrapper: RouterWrapper,
    });
    fireEvent.change(getByTestId("input"), { target: { value: "John" } });
    fireEvent.blur(getByTestId("input"));
    expect(queryByTestId("providerFirstNameError")).toBeNull();
  });
});
