import { cleanup, render } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import ProviderSummary from "Components/Templates/ProviderList/ProviderSummary";
import providerSummary from "./mockdata/mockProviderSummary.json";

const RouterWrapper = ({ children }) => <MemoryRouter>{children}</MemoryRouter>;

afterEach(cleanup);

describe("Test the Provider List Component", () => {
  test("it renders correctly", () => {
    render(<ProviderSummary providerSummary={providerSummary} />, {
      wrapper: RouterWrapper,
    });
  });
});
