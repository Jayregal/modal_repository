import { render } from "@testing-library/react";
import ChangeLocation from "Components/UI/Organisms/ChangeLocation";

describe("Test the Change Location Component", () => {
  test("it renders without crashing", () => {
    render(<ChangeLocation />);
  });
});
