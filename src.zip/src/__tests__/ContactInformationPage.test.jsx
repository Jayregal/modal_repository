import { render } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import ContactInformationPage from "Components/Templates/DataPages/ContactInformationPage";

const RouterWrapper = ({ children }) => <MemoryRouter>{children}</MemoryRouter>;

describe("Test the Contact Information Component", () => {
  test("it renders without crashing", () => {
    render(<ContactInformationPage />, {
      wrapper: RouterWrapper,
    });
  });
});
