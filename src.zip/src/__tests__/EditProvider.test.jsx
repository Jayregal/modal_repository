import { render, cleanup, screen, fireEvent } from "@testing-library/react";
import EditProvider from "Components/Templates/ProviderList/EditProvider";
import { MemoryRouter } from "react-router-dom";
import providerSummary from "./mockdata/mockProviderSummary.json";
import * as yup from "yup";
import { Button } from "react-bootstrap";
import addIcon from "Components/Templates/ProviderList/add-icon.svg";
import { Formik, Form } from "formik";

const RouterWrapper = ({ children }) => <MemoryRouter>{children}</MemoryRouter>;

afterEach(cleanup);

describe("Test the Edit Provider Component", () => {
  let modalShow;
  let setModalShow;
  beforeEach(() => {
    modalShow = false;
    setModalShow = jest.fn(() => {
      modalShow = true;
    });
  });

  test("it should renders without crashing", () => {
    render(<EditProvider providerSummary={providerSummary} />, {
      wrapper: RouterWrapper,
    });
  });
  test("should show labels in Edit Provider form", () => {
    render(<EditProvider providerSummary={providerSummary} />, {
      wrapper: RouterWrapper,
    });
    const label = screen.getByText(/first name/i);
    expect(label).toBeInTheDocument();
    // expect(getByText(/middle initial/i)).toBeInTheDocument()
  });
  test("render add Location component in the document", () => {
    const { getByText } = render(
      <EditProvider providerSummary={providerSummary} />,
      { wrapper: RouterWrapper }
    );
    const childElement = getByText(
      /please confirm that all information is correct/i
    );
    expect(childElement).toBeTruthy();
  });
  test("test the confirm and save button on the document", () => {
    render(<EditProvider providerSummary={providerSummary} />, {
      wrapper: RouterWrapper,
    });
    const buttonElement = screen.getByRole("button", {
      name: /confirm and save/i,
    });
    console.log("buttons", buttonElement);
    expect(buttonElement).toBeTruthy();
  });

  const validationSchema = yup.object({
    firstName: yup
      .string()
      .max(25, "Too Long!")
      .matches(/^[aA-zZ\s]+$/, "Name cannot contain numbers ")
      .required("First Name is required"),
    middleName: yup
      .string()
      .nullable()
      .max(25, "Too Long!")
      .matches(/^[aA-zZ\s]+$/, "Name cannot contain numbers"),
    lastName: yup
      .string()
      .max(25, "Too Long!")
      .matches(/^[A-Za-z\s'_.-]+$/, "Name cannot contain numbers ")
      .required("Last Name is required"),
    mdofficeId: yup.string().max(25, "Too Long!"),
    npi: yup
      .string()
      .required("NPI is required")
      .min(10, "NPI should be 10 digits")
      .max(10, "NPI should be 10 digits")
      .matches(/^[0-9]+$/, "Must be only digits"),
    preferredEmailAddress: yup
      .string()
      .email("Invalid email format")
      .required("Email required."),
    sentaraEmailAddress: yup.string().email("Invalid email format"),
  });

  test("validates a valid name", async () => {
    await expect(
      validationSchema.validate({
        firstName: "John",
        middleName: "Ling",
        lastName: "King",
        mdofficeId: "AXVANVOO",
        npi: "1234567890",
        preferredEmailAddress: "test@gmail.com",
        sentaraEmailAddress: "test@sentara.com",
      })
    ).resolves.toEqual({
      firstName: "John",
      middleName: "Ling",
      lastName: "King",
      mdofficeId: "AXVANVOO",
      npi: "1234567890",
      preferredEmailAddress: "test@gmail.com",
      sentaraEmailAddress: "test@sentara.com",
    });
  });
  test("fails validation for a name that is too long", async () => {
    await expect(
      validationSchema.validate({
        firstName: "a".repeat(26),
        middleName: "a".repeat(26),
        lastName: "a".repeat(26),
        mdofficeId: "a".repeat(26),
        npi: "1234567890",
        preferredEmailAddress: "test@gmail.com",
        sentaraEmailAddress: "test@sentara.com",
      })
    ).rejects.toThrow("Too Long!");
  });
  test("fails validation for NPI should be 10 digits", async () => {
    await expect(
      validationSchema.validate({
        firstName: "a".repeat(25),
        middleName: "a".repeat(25),
        lastName: "a".repeat(25),
        mdofficeId: "a".repeat(25),
        npi: "a".repeat(11),
        preferredEmailAddress: "test@gmail.com",
        sentaraEmailAddress: "test@sentara.com",
      })
    ).rejects.toThrow("NPI should be 10 digits");
  });
  test("fails validation for NPI should be 10 digits", async () => {
    await expect(
      validationSchema.validate({
        firstName: "a".repeat(25),
        middleName: "a".repeat(25),
        lastName: "a".repeat(25),
        mdofficeId: "a".repeat(25),
        npi: "a".repeat(9),
        preferredEmailAddress: "test@gmail.com",
        sentaraEmailAddress: "test@sentara.com",
      })
    ).rejects.toThrow("NPI should be 10 digits");
  });
  test("fails validation for a name that contains numbers", async () => {
    await expect(
      validationSchema.validate({
        firstName: "John1",
        middleName: "Ling1",
        lastName: "King1",
        npi: "1111111111",
        preferredEmailAddress: "test@gmail.com",
        sentaraEmailAddress: "test@sentara.com",
      })
    ).rejects.toThrow("Name cannot contain numbers");
  });
  test("fails validation for a email format", async () => {
    await expect(
      validationSchema.validate({
        firstName: "John1",
        middleName: "Ling1",
        lastName: "King1",
        npi: "1111111111",
        preferredEmailAddress: "test",
        sentaraEmailAddress: "test",
      })
    ).rejects.toThrow("Invalid email format");
  });
  test("fails validation for a missing value", async () => {
    await expect(
      validationSchema.validate({
        lastName: "King",
        npi: "1234567890",
        preferredEmailAddress: "test@gmail.com",
        sentaraEmailAddress: "test@sentara.com",
      })
    ).rejects.toThrow("First Name is required");
  });
  test("fails validation for a missing value", async () => {
    await expect(
      validationSchema.validate({
        firstName: "John",
        middleName: "Ling",
        npi: "1234567890",
        preferredEmailAddress: "test@gmail.com",
        sentaraEmailAddress: "test@sentara.com",
      })
    ).rejects.toThrow("Last Name is required");
  });
  test("fails validation for a missing value", async () => {
    await expect(
      validationSchema.validate({
        firstName: "John",
        middleName: "Ling",
        lastName: "King",
        preferredEmailAddress: "test@gmail.com",
        sentaraEmailAddress: "test@sentara.com",
      })
    ).rejects.toThrow("NPI is required");
  });
  test("fails validation for a missing value", async () => {
    await expect(
      validationSchema.validate({
        firstName: "John",
        middleName: "Ling",
        lastName: "King",
        sentaraEmailAddress: "test@sentara.com",
      })
    ).rejects.toThrow("Email required.");
  });

  test("renders correct label text", () => {
    const { getByText } = render(
      <EditProvider
        labels={{ TITLE: "Title" }}
        providerSummary={providerSummary}
      />,
      {
        wrapper: MemoryRouter,
      }
    );
    const label = getByText("Title");
    expect(label).toBeInTheDocument();
  });

  test("renders the button with text Add Location", () => {
    const { getByText } = render(
      <Button
        variant="primary"
        onClick={() => setModalShow(true)}
        className="add-location"
      >
        <span>
          <img src={addIcon} alt="add icon" />
        </span>
        Add Location
      </Button>
    );
    const button = getByText("Add Location");
    expect(button).toBeInTheDocument();
  });

  test("modalShow is set to true when button is clicked", () => {
    const { getByText } = render(
      <Button
        variant="primary"
        onClick={() => setModalShow(true)}
        className="add-location"
      >
        <span>
          <img src={addIcon} alt="add icon" />
        </span>
        Add Location
      </Button>
    );
    const button = getByText("Add Location");
    fireEvent.click(button);
    expect(modalShow).toBe(true);
  });

  test("className should be error-field nb-input when formik.touched.firstName and formik.errors.firstName are truthy", () => {
    const formik = {
      touched: { firstName: true },
      errors: { firstName: true },
    };

    const { container } = render(
      <div
        className={
          formik.touched.firstName && formik.errors.firstName
            ? "error-field nb-input"
            : "nb-input"
        }
      />
    );

    expect(container.firstChild).toHaveClass("error-field nb-input");
  });

  test("className should be nb-input when formik.touched.firstName is truthy and formik.errors.firstName is falsy", () => {
    const formik = {
      touched: { firstName: true },
      errors: { firstName: false },
    };

    const { container } = render(
      <div
        className={
          formik.touched.firstName && formik.errors.firstName
            ? "error-field nb-input"
            : "nb-input"
        }
      />
    );
    expect(container.firstChild).toHaveClass("nb-input");
  });

  test("className should be nb-input when formik.touched.firstName is falsy and formik.errors.firstName is truthy", () => {
    const formik = {
      touched: { firstName: false },
      errors: { firstName: true },
    };
    const { container } = render(
      <div
        className={
          formik.touched.firstName && formik.errors.firstName
            ? "error-field nb-input"
            : "nb-input"
        }
      />
    );
    expect(container.firstChild).toHaveClass("nb-input");
  });

  test("className should be error-field nb-input when formik.touched.firstName and formik.errors.firstName are truthy", () => {
    const formik = {
      touched: { firstName: true },
      errors: { firstName: true },
    };

    const { container } = render(
      <div
        className={
          formik.touched.firstName && formik.errors.firstName
            ? "error-field nb-input"
            : "nb-input"
        }
      />
    );

    expect(container.firstChild).toHaveClass("error-field nb-input");
  });

  test("className should be nb-input when formik.touched.firstName is truthy and formik.errors.firstName is falsy", () => {
    const formik = {
      touched: { firstName: true },
      errors: { firstName: false },
    };

    const { container } = render(
      <div
        className={
          formik.touched.firstName && formik.errors.firstName
            ? "error-field nb-input"
            : "nb-input"
        }
      />
    );
    expect(container.firstChild).toHaveClass("nb-input");
  });

  test("className should be nb-input when formik.touched.firstName is falsy and formik.errors.firstName is truthy", () => {
    const formik = {
      touched: { firstName: false },
      errors: { firstName: true },
    };
    const { container } = render(
      <div
        className={
          formik.touched.firstName && formik.errors.firstName
            ? "error-field nb-input"
            : "nb-input"
        }
      />
    );
    expect(container.firstChild).toHaveClass("nb-input");
  });

  it("renders error message when firstName field has touch error", () => {
    const formik = {
      touched: { firstName: true },
      errors: { firstName: "First Name is required" },
    };
    const { getByTestId } = render(
      <Formik {...formik}>
        <Form>
          <EditProvider providerSummary={providerSummary} />
        </Form>
      </Formik>,
      {
        wrapper: RouterWrapper,
      }
    );
    const firstNameError = getByTestId("providerFirstNameError");
    expect(firstNameError).toHaveTextContent("First Name is required");
  });

  it("does not render error message when firstName field does not have touch error", () => {
    const formik = {
      touched: { firstName: false },
      errors: { firstName: "First Name is required" },
    };
    const { queryByTestId } = render(
      <Formik {...formik}>
        <Form>
          <EditProvider providerSummary={providerSummary} />
        </Form>
      </Formik>,
      {
        wrapper: RouterWrapper,
      }
    );
    const firstNameError = queryByTestId("providerFirstNameError");
    expect(firstNameError).toBeNull();
  });
  it("renders error message when middleName field has touch error", () => {
    const formik = {
      touched: { middleName: true },
      errors: { middleName: "This is a middle name error" },
    };
    const { getByTestId } = render(
      <Formik {...formik}>
        <Form>
          <EditProvider providerSummary={providerSummary} />
        </Form>
      </Formik>,
      {
        wrapper: RouterWrapper,
      }
    );
    const middleNameError = getByTestId("providerMiddleNameError");
    expect(middleNameError).toHaveTextContent("This is a middle name error");
  });

  it("does not render error message when middleName field does not have touch error", () => {
    const formik = {
      touched: { middleName: false },
      errors: { middleName: "This is a middle name error" },
    };
    const { queryByTestId } = render(
      <Formik {...formik}>
        <Form>
          <EditProvider providerSummary={providerSummary} />
        </Form>
      </Formik>,
      {
        wrapper: RouterWrapper,
      }
    );
    const middleNameError = queryByTestId("providerMiddleNameError");
    expect(middleNameError).toBeNull();
  });

  it("renders the title dropdown correctly", () => {
    const data = [
      { id: 1, title: "Test Title 1" },
      { id: 2, title: "Test Title 2" },
      { id: 3, title: "Test Title 3" },
    ];
    const selectedTitle = "Test Title 1";
    const setSelectedTitle = jest.fn();
    const setProviderEdit = jest.fn();

    const { getByTestId } = render(
      <EditProvider
        data={data}
        selectedTitle={selectedTitle}
        setSelectedTitle={setSelectedTitle}
        setProviderEdit={setProviderEdit}
      />,
      {
        wrapper: RouterWrapper,
      }
    );

    const titleButton1 = getByTestId("title-button-1");
    expect(titleButton1).toBeInTheDocument();
    expect(titleButton1).toHaveTextContent("Test Title 1");

    fireEvent.click(titleButton1);
    expect(setSelectedTitle).toHaveBeenCalledWith("Test Title 1");
    expect(setProviderEdit).toHaveBeenCalled();
  });
});
