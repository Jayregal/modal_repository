import { render } from "@testing-library/react";
import PracticeDropdown from "Components/Smart-Components/PracticeDropdown";

describe("Test the Practice Dropdown Component", () => {
  test("it renders without crashing", () => {
    render(<PracticeDropdown />);
  });
});
