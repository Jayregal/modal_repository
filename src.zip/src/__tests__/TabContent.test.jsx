import { render } from "@testing-library/react";
import TabContent from "Components/Templates/Tabs/TabContent";

describe("Test the Tab Content Component", () => {
  test("it renders without crashing", () => {
    render(<TabContent />);
  });
});
