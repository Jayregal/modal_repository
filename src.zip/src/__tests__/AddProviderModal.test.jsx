import { render } from "@testing-library/react";
import AddProviderModal from "Components/Templates/ProviderList/AddProviderModal";

describe("Test the Contact Information Component", () => {
  test("it renders without crashing", () => {
    render(<AddProviderModal />);
  });
});
