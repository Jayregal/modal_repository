import { render, screen, cleanup } from "@testing-library/react";
import Paragraph from "Components/UI/Atoms/Paragraph/Paragraph";
import renderer from "react-test-renderer";

afterEach(cleanup);

describe("Test the Paragraph Component", () => {
  test("renders Location & Providers count in the document", () => {
    render(<Paragraph />);
    const linkElement = screen.getByTestId("locprovcount");
    expect(linkElement).toBeInTheDocument();
  });

  test("should render the component correctly", () => {
    const tree = renderer.create(<Paragraph />).toJSON();
    expect(tree).toMatchSnapshot();
  });
});
