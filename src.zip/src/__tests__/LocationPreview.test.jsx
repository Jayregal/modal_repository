import { render } from "@testing-library/react";
import LocationPreview from "Components/UI/Molecules/LocationPreview";

describe("Test the Location Preview Component", () => {
  test("it renders without crashing", () => {
    render(<LocationPreview />);
  });
});
