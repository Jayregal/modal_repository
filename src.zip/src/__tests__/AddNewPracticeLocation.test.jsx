import { render } from "@testing-library/react";
import renderer from "react-test-renderer";
import providerSummary from "./mockdata/mockProviderSummary.json";
import locationListData from "./mockdata/mockLocation.json";
import AddNewPracticeLocation from "Components/UI/Molecules/AddNewPracticeLocation";

describe("Test the Practice Location Component", () => {
  test("it renders without crashing", () => {
    render(
      <AddNewPracticeLocation
        providerSummary={providerSummary[0]}
        locationListData={locationListData}
      />
    );
  });

  test("should render the component correctly", () => {
    const tree = renderer
      .create(
        <AddNewPracticeLocation
          providerSummary={providerSummary[0]}
          locationListData={locationListData}
        />
      )
      .toJSON();
    expect(tree).toMatchSnapshot();
  });
});
