import { render, cleanup } from "@testing-library/react";
import ProviderSummaryPage from "Components/Templates/DataPages/ProviderSummaryPage";
import { MemoryRouter } from "react-router-dom";

const RouterWrapper = ({ children }) => <MemoryRouter>{children}</MemoryRouter>;

afterEach(cleanup);

describe("Test the Provider Summary Page Component", () => {
  test("it should renders without crashing", () => {
    render(<ProviderSummaryPage />, {
      wrapper: RouterWrapper,
    });
  });
});
