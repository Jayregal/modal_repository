import React from "react";
import { render, cleanup, act } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import Authentication from "Components/Pages/Authentication";
import cookies from "js-cookie";
import { MemoryRouter } from "react-router-dom";

const RouterWrapper = ({ children }) => <MemoryRouter>{children}</MemoryRouter>;

afterEach(() => {
  cookies.remove("access");
  cleanup();
});

describe("Authentication component", () => {
  it("renders without crashing", () => {
    const { asFragment } = render(<Authentication />, {
      wrapper: RouterWrapper,
    });
    expect(asFragment()).toMatchSnapshot();
  });

  it("sets the cookie when token is present in URL", () => {
    const { asFragment } = render(
      <Authentication />,
      {
        wrapper: RouterWrapper,
      },
      {
        route:
          "/authentication?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjYyMzIiLCJmaXJzdG5hbWUiOiJTYW5keSIsImxhc3RuYW1lIjoiTWFzIiwibWRvZmZpY2VpZCI6IlNYTkFSQVkyIiwibmJmIjoxNjc0ODI4NTc0LCJleHAiOjE2NzQ5MTQ5NzQsImlzcyI6InBtdC1wcm92aWRlci5henVyZXdlYnNpdGVzLm5ldCIsImF1ZCI6InNlbnRhcmEuaW5kIn0.1--YxuBIQuiw6IN8AL8xl3gfrnrd8toRmKo5aGcYCMY",
      }
    );
    act(() => {
      // wait for useEffect to run
    });
    expect(cookies.get("access")).toBe(
      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjYyMzIiLCJmaXJzdG5hbWUiOiJTYW5keSIsImxhc3RuYW1lIjoiTWFzIiwibWRvZmZpY2VpZCI6IlNYTkFSQVkyIiwibmJmIjoxNjc0ODI4NTc0LCJleHAiOjE2NzQ5MTQ5NzQsImlzcyI6InBtdC1wcm92aWRlci5henVyZXdlYnNpdGVzLm5ldCIsImF1ZCI6InNlbnRhcmEuaW5kIn0.1--YxuBIQuiw6IN8AL8xl3gfrnrd8toRmKo5aGcYCMY"
    );
    expect(asFragment()).toMatchSnapshot();
  });

  it("renders error server component when Error is present in URL", () => {
    const { asFragment } = render(
      <Authentication />,
      {
        wrapper: RouterWrapper,
      },
      {
        route: "/authentication?Error=404",
      }
    );
    expect(asFragment()).toMatchSnapshot();
  });

  it("gets the token from cookie when token is not present in URL", () => {
    cookies.set(
      "access",
      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjYyMzIiLCJmaXJzdG5hbWUiOiJTYW5keSIsImxhc3RuYW1lIjoiTWFzIiwibWRvZmZpY2VpZCI6IlNYTkFSQVkyIiwibmJmIjoxNjc0ODI4NTc0LCJleHAiOjE2NzQ5MTQ5NzQsImlzcyI6InBtdC1wcm92aWRlci5henVyZXdlYnNpdGVzLm5ldCIsImF1ZCI6InNlbnRhcmEuaW5kIn0.1--YxuBIQuiw6IN8AL8xl3gfrnrd8toRmKo5aGcYCMY"
    );
    const { asFragment } = render(<Authentication />, {
      wrapper: RouterWrapper,
    });
    expect(cookies.get("access")).toBe(
      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjYyMzIiLCJmaXJzdG5hbWUiOiJTYW5keSIsImxhc3RuYW1lIjoiTWFzIiwibWRvZmZpY2VpZCI6IlNYTkFSQVkyIiwibmJmIjoxNjc0ODI4NTc0LCJleHAiOjE2NzQ5MTQ5NzQsImlzcyI6InBtdC1wcm92aWRlci5henVyZXdlYnNpdGVzLm5ldCIsImF1ZCI6InNlbnRhcmEuaW5kIn0.1--YxuBIQuiw6IN8AL8xl3gfrnrd8toRmKo5aGcYCMY"
    );
    expect(asFragment()).toMatchSnapshot();
  });
});
