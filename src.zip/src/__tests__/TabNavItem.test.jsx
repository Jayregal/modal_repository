import { render } from "@testing-library/react";
import TabNavItem from "Components/Templates/Tabs/TabNavItem";

describe("Test the Tab nav item Component", () => {
  test("it renders without crashing", () => {
    render(<TabNavItem />);
  });
});
