import { render } from "@testing-library/react";
import LocationDropdownList from "Components/UI/Molecules/LocationDropdownList";
import locationListData from "./mockdata/mockLocation.json";

describe("Test the Location Dropdownlist Component", () => {
  test("renders without crashing", () => {
    render(<LocationDropdownList dataList={locationListData} />);
  });
});
