import { render, cleanup, fireEvent } from "@testing-library/react";
import ListItem from "Components/UI/Atoms/ListItem";
import renderer from "react-test-renderer";
import practiceListData from "./mockdata/mockPracticeSummary.json";

afterEach(cleanup);

describe("Test the ListItem Component", () => {
  test("it renders correctly", () => {
    render(<ListItem />);
  });

  test("should render the component correctly", () => {
    const tree = renderer.create(<ListItem />).toJSON();
    expect(tree).toMatchSnapshot();
  });

  test("test onItemClick event", () => {
    const onItemClicked = jest.fn();
    const { getByTestId } = render(
      <ListItem
        practiceListData={practiceListData}
        onItemClicked={onItemClicked}
        dataList={practiceListData}
        id={practiceListData.practiceId}
        name={practiceListData.practiceName}
      />
    );
    const button = getByTestId("practiceNameDropDown");
    fireEvent.click(button);
    expect(onItemClicked).toHaveBeenCalled();
  });
});
