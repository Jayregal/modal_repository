import { cleanup, render, screen } from "@testing-library/react";
import renderer from "react-test-renderer";
import ErrorServer from "Components/Hooks/Error404";

afterEach(cleanup);

describe("Test the Error404 Component", () => {
  test("renders loading in the document", () => {
    render(<ErrorServer />);
    const linkElement = screen.getByTestId("error-server");
    expect(linkElement).toBeInTheDocument();
  });

  test("should render the component correctly", () => {
    const tree = renderer.create(<ErrorServer />).toJSON();
    expect(tree).toMatchSnapshot();
  });
});
