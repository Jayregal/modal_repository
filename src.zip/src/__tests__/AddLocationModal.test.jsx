import React from "react";
import { render, fireEvent, waitFor } from "@testing-library/react";
import AddLocationModal from "Components/Templates/ProviderList/AddLocationModal";

describe("Test the Contact Information Component", () => {
  test("check initial state of form inputs", () => {
    const { getByTestId } = render(<AddLocationModal />);

    expect(getByTestId("LocationName").value).toBe("");
    expect(getByTestId("Provider").checked).toBe(true);
    expect(getByTestId("Type").value).toBe("1");
  });

  test("form input changes", async () => {
    const { getByTestId } = render(<AddLocationModal />);

    fireEvent.change(getByTestId("LocationName"), {
      target: { value: "test" },
    });
    expect(getByTestId("LocationName").value).toBe("test");

    fireEvent.change(getByTestId("Provider"), { target: { checked: false } });
    expect(getByTestId("Provider").checked).toBe(false);

    fireEvent.change(getByTestId("Type"), { target: { value: "2" } });
    expect(getByTestId("Type").value).toBe("2");
  });

  test("form submit", async () => {
    const clickHandler = jest.fn();
    const { getByTestId } = render(
      <AddLocationModal clickHandler={clickHandler} />
    );

    fireEvent.submit(getByTestId("Submit"));
    await waitFor(() => expect(clickHandler).toHaveBeenCalled());
  });

  test("onCancel", async () => {
    const onHide = jest.fn();
    const { getByText } = render(
      <AddLocationModal onHide={onHide} show={true} />
    );

    fireEvent.click(getByText("Cancel"));
    await waitFor(() => expect(onHide).toHaveBeenCalled());
  });
});
