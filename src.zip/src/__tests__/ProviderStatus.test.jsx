import moment from "moment";
import { cleanup } from "@testing-library/react";
import { providerStatus } from "Components/Templates/ProviderList/ProviderList";
import UpdateRequired from "Components/Templates/ProviderList/images/Icon-update-required.svg";
import Updated from "Components/Templates/ProviderList/images/Icon-updated.svg";
import Inactive from "Components/Templates/ProviderList/images/Icon-inactive.svg";
import { stillAtLocation } from "Components/Templates/ProviderList/ProviderList";

afterEach(cleanup);

describe("providerStatus", () => {
  it("returns Inactive status when difference between given date and today is more than 90 days", () => {
    const lastConfirmedDate = moment().subtract(100, "days").toDate();
    const inactiveProvider = null;
    const result = providerStatus(lastConfirmedDate, inactiveProvider);
    expect(result.type).toEqual("img");
    expect(result.props.src).toEqual(Inactive);
    expect(result.props.alt).toEqual("Inactive");
  });

  it("returns Update Required status when difference between given date and today is more than 3 days", () => {
    const lastConfirmedDate = moment().subtract(5, "days").toDate();
    const inactiveProvider = null;
    const result = providerStatus(lastConfirmedDate, inactiveProvider);
    expect(result.type).toEqual("img");
    expect(result.props.src).toEqual(UpdateRequired);
    expect(result.props.alt).toEqual("Update Required");
  });

  it("returns Updated status when difference between given date and today is less than or equal to 3 days", () => {
    const lastConfirmedDate = moment().subtract(2, "days").toDate();
    const inactiveProvider = null;
    const result = providerStatus(lastConfirmedDate, inactiveProvider);
    expect(result.type).toEqual("img");
    expect(result.props.src).toEqual(Updated);
    expect(result.props.alt).toEqual("Updated");
  });

  it("returns Inactive status when inactiveProvider is not null", () => {
    const lastConfirmedDate = moment().toDate();
    const inactiveProvider = "not null";
    const result = providerStatus(lastConfirmedDate, inactiveProvider);
    expect(result.type).toEqual("img");
    expect(result.props.src).toEqual(Inactive);
    expect(result.props.alt).toEqual("Inactive");
  });

  it("returns Yes when givenDate is null", () => {
    const result = stillAtLocation(null);
    expect(result).toEqual("Yes");
  });

  it("returns No when givenDate is not null", () => {
    const result = stillAtLocation(new Date());
    expect(result).toEqual("No");
  });
});
