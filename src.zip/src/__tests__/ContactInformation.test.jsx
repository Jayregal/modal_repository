import { cleanup, render, screen } from "@testing-library/react";
import renderer from "react-test-renderer";
import ContactInformation from "Components/Templates/ContactInformation/ContactInformation";
import data from "./mockdata/mockContactInformation.json";

afterEach(cleanup);

describe("Test the Contact Information Component", () => {
  test("it renders without crashing", () => {
    render(<ContactInformation data={data[0]} />);
  });

  test("renders Information Text in the document", () => {
    const { container } = render(<ContactInformation data={data[0]} />);
    const linkElement = container.getElementsByClassName("info-text");
    expect(linkElement).toBeTruthy();
  });

  test("it checks branches with Practice Manager Name data", () => {
    render(<ContactInformation data={data[0]} />);
    const nameElement4 = screen.getAllByTestId("PracticeManagerName");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with out Practice Manager Name data", () => {
    render(<ContactInformation data={data[1]} />);
    const nameElement4 = screen.getAllByTestId("NoPracticeManagerName");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with Practice Manager Email data", () => {
    render(<ContactInformation data={data[0]} />);
    const nameElement4 = screen.getAllByTestId("PracticeManagerEmail");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with out Practice Manager Email data", () => {
    render(<ContactInformation data={data[1]} />);
    const nameElement4 = screen.getAllByTestId("NoPracticeManagerEmail");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with Practice Manager Phone data", () => {
    render(<ContactInformation data={data[0]} />);
    const nameElement4 = screen.getAllByTestId("PracticeManagerPhone");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with out Practice Manager Phone data", () => {
    render(<ContactInformation data={data[1]} />);
    const nameElement4 = screen.getAllByTestId("noPracticeManagerPhone");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with Practice Manager MD Office ID data", () => {
    render(<ContactInformation data={data[0]} />);
    const nameElement4 = screen.getAllByTestId("PracticeManagerMdoffice");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with out Practice Manager MD Office Id data", () => {
    render(<ContactInformation data={data[1]} />);
    const nameElement4 = screen.getAllByTestId("noPracticeManagerMdoffice");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with Practice Manager Primary SQCN data", () => {
    render(<ContactInformation data={data[0]} />);
    const nameElement4 = screen.getAllByTestId("PmPrimarySqcn");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with out Practice Manager Primary SQCN data", () => {
    render(<ContactInformation data={data[1]} />);
    const nameElement4 = screen.getAllByTestId("noPmPrimarySqcn");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with Additional Point of contact name data", () => {
    render(<ContactInformation data={data[0]} />);
    const nameElement4 = screen.getAllByTestId("AdditionalName");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with out Additional Point of contact name data", () => {
    render(<ContactInformation data={data[1]} />);
    const nameElement4 = screen.getAllByTestId("noAdditionalName");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with Additional Point of contact Email data", () => {
    render(<ContactInformation data={data[0]} />);
    const nameElement4 = screen.getAllByTestId("AdditionalEmail");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with out Additional Point of contact Email data", () => {
    render(<ContactInformation data={data[1]} />);
    const nameElement4 = screen.getAllByTestId("noAdditionalEmail");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with Additional Point of contact Phone data", () => {
    render(<ContactInformation data={data[0]} />);
    const nameElement4 = screen.getAllByTestId("AdditionalPhoneData");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with out Additional Point of contact Phone data", () => {
    render(<ContactInformation data={data[1]} />);
    const nameElement4 = screen.getAllByTestId("noAdditionalPhoneData");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with Additional Point of contact MD Office data", () => {
    render(<ContactInformation data={data[0]} />);
    const nameElement4 = screen.getAllByTestId("AdditionalMdoffice");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with out Additional Point of contact MD Office data", () => {
    render(<ContactInformation data={data[1]} />);
    const nameElement4 = screen.getAllByTestId("NoAdditionalMdoffice");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with Additional Point of contact Primary SQCN data", () => {
    render(<ContactInformation data={data[0]} />);
    const nameElement4 = screen.getAllByTestId("AdditionalPrimarySqcn");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with out Additional Point of contact Primary SQCN data", () => {
    render(<ContactInformation data={data[1]} />);
    const nameElement4 = screen.getAllByTestId("NoAdditionalPrimarySqcn");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with Director Name data", () => {
    render(<ContactInformation data={data[0]} />);
    const nameElement4 = screen.getAllByTestId("DirectorName");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with out Director Name data", () => {
    render(<ContactInformation data={data[1]} />);
    const nameElement4 = screen.getAllByTestId("noDirectorName");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with Director Email data", () => {
    render(<ContactInformation data={data[0]} />);
    const nameElement4 = screen.getAllByTestId("DirectorEmail");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with out Director Email data", () => {
    render(<ContactInformation data={data[1]} />);
    const nameElement4 = screen.getAllByTestId("noDirectorEmail");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with Director Phone data", () => {
    render(<ContactInformation data={data[0]} />);
    const nameElement4 = screen.getAllByTestId("DirectorPhone");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with out Director Phone data", () => {
    render(<ContactInformation data={data[1]} />);
    const nameElement4 = screen.getAllByTestId("noDirectorPhone");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with Director MD Office Id data", () => {
    render(<ContactInformation data={data[0]} />);
    const nameElement4 = screen.getAllByTestId("DirectorMdOffice");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with out Director MD Office data", () => {
    render(<ContactInformation data={data[1]} />);
    const nameElement4 = screen.getAllByTestId("noDirectorMdOffice");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with Executive Name data", () => {
    render(<ContactInformation data={data[0]} />);
    const nameElement4 = screen.getAllByTestId("ExecutiveName");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with out Executive Name data", () => {
    render(<ContactInformation data={data[1]} />);
    const nameElement4 = screen.getAllByTestId("noExecutiveName");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with Executive Email data", () => {
    render(<ContactInformation data={data[0]} />);
    const nameElement4 = screen.getAllByTestId("ExecutiveEmail");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with out Executive Email data", () => {
    render(<ContactInformation data={data[1]} />);
    const nameElement4 = screen.getAllByTestId("noExecutiveEmail");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with Executive Phone data", () => {
    render(<ContactInformation data={data[0]} />);
    const nameElement4 = screen.getAllByTestId("ExecutivePhone");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with out Executive Phone data", () => {
    render(<ContactInformation data={data[1]} />);
    const nameElement4 = screen.getAllByTestId("noExecutivePhone");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with Physician Name data", () => {
    render(<ContactInformation data={data[0]} />);
    const nameElement4 = screen.getAllByTestId("PhysicianName");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with out Physician Name data", () => {
    render(<ContactInformation data={data[1]} />);
    const nameElement4 = screen.getAllByTestId("noPhysicianName");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with Physician Email data", () => {
    render(<ContactInformation data={data[0]} />);
    const nameElement4 = screen.getAllByTestId("PhysicianEmail");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with out Physician Email data", () => {
    render(<ContactInformation data={data[1]} />);
    const nameElement4 = screen.getAllByTestId("noPhysianEmail");
    expect(nameElement4).toHaveLength(1);
  });

  test("should render the component correctly", () => {
    const tree = renderer
      .create(<ContactInformation data={data[0]} />)
      .toJSON();
    expect(tree).toMatchSnapshot();
  });
});
