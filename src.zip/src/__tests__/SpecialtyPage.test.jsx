import { render, cleanup } from "@testing-library/react";
import SpecialtyPage from "Components/Templates/DataPages/SpecialtyPage";
import renderer from "react-test-renderer";

afterEach(cleanup);

describe("Test the Add Provider Component", () => {
  test("it should renders without crashing", () => {
    render(<SpecialtyPage />);
  });

  test("should render the component correctly", () => {
    const tree = renderer.create(<SpecialtyPage />).toJSON();
    expect(tree).toMatchSnapshot();
  });
});
