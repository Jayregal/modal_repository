import { cleanup, render, screen } from "@testing-library/react";
import renderer from "react-test-renderer";
import Spinner from "Components/Hooks/Spinner";

afterEach(cleanup);

describe("Test the Spinner Component", () => {
  test("renders loading in the document", () => {
    render(<Spinner />);
    const linkElement = screen.getByTestId("loader");
    expect(linkElement).toBeInTheDocument();
  });

  test("should render the component correctly", () => {
    const tree = renderer.create(<Spinner />).toJSON();
    expect(tree).toMatchSnapshot();
  });
});
