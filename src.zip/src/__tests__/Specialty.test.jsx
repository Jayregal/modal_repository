import React from "react";
import { render, fireEvent } from "@testing-library/react";
import BoardSpecialty from "Components/UI/Organisms/Specialty";

const specialtydata = [
  { id: 1, specialtyName: "Cardiology" },
  { id: 2, specialtyName: "Dermatology" },
  { id: 3, specialtyName: "Oncology" },
  { id: 4, specialtyName: "Orthopedics" },
  { id: 5, specialtyName: "Pediatrics" },
];

describe("BoardSpecialty", () => {
  it("should render the component", () => {
    const { getByTestId } = render(
      <BoardSpecialty
        specialtydata={specialtydata}
        selectedSpecialtyIdfn={() => {}}
      />
    );
    expect(getByTestId("specialty-input")).toBeInTheDocument();
  });

  it("should update the selectedSpecialty state when onChange is triggered", () => {
    const { getByTestId } = render(
      <BoardSpecialty
        specialtydata={specialtydata}
        selectedSpecialtyIdfn={() => {}}
      />
    );
    const input = getByTestId("specialty-input");
    fireEvent.change(input, { target: { value: "Cardiology" } });
    expect(input.value).toBe("Cardiology");
  });

  it("should call the selectedSpecialtyIdfn function with the correct arguments when onSearch is triggered", () => {
    const selectedSpecialtyIdfn = jest.fn();
    const { getByTestId } = render(
      <BoardSpecialty
        specialtydata={specialtydata}
        selectedSpecialtyIdfn={() => {}}
      />
    );
    const input = getByTestId("specialty-input");
    fireEvent.change(input, { target: { value: "Cardiology" } });
    const button = getByTestId("dropdown-row-1");
    fireEvent.click(button);
    expect(selectedSpecialtyIdfn).toHaveBeenCalledWith(
      1,
      "Cardiology",
      specialtydata
    );
  });
});
