import React from "react";
import { render, fireEvent } from "@testing-library/react";
import AddLocationModalPage from "Components/Templates/DataPages/AddLocationModalPage";

describe("AddLocationModalPage", () => {
  let modalShow, setModalShow, clickHandler;

  beforeEach(() => {
    modalShow = false;
    setModalShow = jest.fn();
    clickHandler = jest.fn();
  });

  test("shows modal when modalShow is set to true", () => {
    modalShow = true;
    const { getByTestId } = render(
      <AddLocationModalPage
        show={modalShow}
        onHide={() => setModalShow(false)}
        clickHandler={clickHandler}
      />
    );
    expect(getByTestId("modal")).toBeVisible();
  });

  test("hides modal when modalShow is set to false", () => {
    modalShow = false;
    const { queryByTestId } = render(
      <AddLocationModalPage
        show={modalShow}
        onHide={() => setModalShow(false)}
        clickHandler={clickHandler}
      />
    );
    expect(queryByTestId("modal")).toBeNull();
  });

  test("calls setModalShow when close button is clicked", () => {
    modalShow = true;
    const { getByTestId } = render(
      <AddLocationModalPage
        show={modalShow}
        onHide={() => setModalShow(false)}
        clickHandler={clickHandler}
      />
    );
    fireEvent.click(getByTestId("close-button"));
    expect(setModalShow).toHaveBeenCalled();
  });

  test("calls clickHandler when form is submitted", () => {
    modalShow = true;
    const { getByTestId } = render(
      <AddLocationModalPage
        show={modalShow}
        onHide={() => setModalShow(false)}
        clickHandler={clickHandler}
      />
    );
    fireEvent.submit(getByTestId("form"));
    expect(clickHandler).toHaveBeenCalled();
  });
});
