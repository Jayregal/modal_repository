import { render, cleanup, screen, waitFor } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import PracticeBannerPage from "Components/Templates/DataPages/PracticeBannerPage";

const RouterWrapper = ({ children }) => <MemoryRouter>{children}</MemoryRouter>;

afterEach(cleanup);

describe("Test the Add Provider Component", () => {
  test("it should renders without crashing", () => {
    render(<PracticeBannerPage />, {
      wrapper: RouterWrapper,
    });
  });

  test("should not show Error Message when API success", () => {
    expect(screen.queryByRole("ErrorServer")).not.toBeInTheDocument();
  });

  test("should not show Error Message when API fail", async () => {
    await waitFor(() =>
      expect(screen.getByRole("ErrorServer")).toBeInTheDocument()
    );
  });

  test("should not show Practice Banner when data empty", () => {
    expect(screen.queryByRole("PracticeBanner")).not.toBeInTheDocument();
  });
});
