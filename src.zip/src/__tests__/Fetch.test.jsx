import { render } from "@testing-library/react";
import { useFetch } from "Components/Hooks/Fetch";

describe("Test the Fetch Component", () => {
  test("it renders without crashing", () => {
    render(useFetch);
  });
});
