import { cleanup, render, screen, fireEvent } from "@testing-library/react";
import ProviderList from "Components/Templates/ProviderList/ProviderList";
import providerList from "./mockdata/mockProviderList.json";
import { MemoryRouter } from "react-router-dom";
import locationListData from "./mockdata/mockLocation.json";
import AddProviderModal from "Components/Templates/ProviderList/AddProviderModal";

const RouterWrapper = ({ children }) => <MemoryRouter>{children}</MemoryRouter>;

afterEach(cleanup);

describe("Test the Provider List Component", () => {
  test("renders Add Provider button in the document", () => {
    render(
      <ProviderList
        providerList={providerList[0]}
        locationListData={locationListData[0]}
      />,
      {
        wrapper: RouterWrapper,
      }
    );
    const linkElement = screen.getByTestId("addprovider");
    expect(linkElement).toBeInTheDocument();
  });

  test("it checks branches with email data", () => {
    render(
      <ProviderList
        providerList={providerList[0]}
        locationListData={locationListData[0]}
      />,
      {
        wrapper: RouterWrapper,
      }
    );
    const nameElement4 = screen.getAllByTestId("providerEmail15");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with out email data", () => {
    render(
      <ProviderList
        providerList={providerList[1]}
        locationListData={locationListData[1]}
      />,
      {
        wrapper: RouterWrapper,
      }
    );
    const nameElement4 = screen.getAllByTestId("NoproviderEmail");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with data", () => {
    render(
      <ProviderList
        providerList={providerList[0]}
        locationListData={locationListData[0]}
      />,
      {
        wrapper: RouterWrapper,
      }
    );
    const nameElement4 = screen.getAllByTestId("ProviderData");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with out data", () => {
    render(
      <ProviderList
        providerList={providerList[2]}
        locationListData={locationListData[1]}
      />,
      {
        wrapper: RouterWrapper,
      }
    );
    const nameElement4 = screen.getAllByTestId("noProviderData");
    expect(nameElement4).toHaveLength(1);
  });
  test("it checks branches with title data", () => {
    render(
      <ProviderList
        providerList={providerList[0]}
        locationListData={locationListData[0]}
      />,
      {
        wrapper: RouterWrapper,
      }
    );
    const nameElement4 = screen.getAllByTestId("providerTitle15");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with out title data", () => {
    render(
      <ProviderList
        providerList={providerList[1]}
        locationListData={locationListData[1]}
      />,
      {
        wrapper: RouterWrapper,
      }
    );
    const nameElement4 = screen.getAllByTestId("NoproviderTitle");
    expect(nameElement4).toHaveLength(1);
  });

  it("sets modalShow to true when button is clicked", () => {
    let modalShow = false;
    const setModalShow = (value) => {
      modalShow = value;
    };
    const { getByTestId } = render(
      <ProviderList setModalShow={setModalShow} />
    );
    const button = getByTestId("addprovider");
    fireEvent.click(button);
    expect(modalShow).toBe(true);
  });

  it("does not set modalShow to true when button is not clicked", () => {
    let modalShow = false;
    const setModalShow = (value) => {
      modalShow = value;
    };
    render(<ProviderList setModalShow={setModalShow} />);
    expect(modalShow).toBe(false);
  });

  it("is not visible when modalShow is false", () => {
    const { queryByTestId } = render(<AddProviderModal show={false} />);
    expect(queryByTestId("addprovidermodal")).toBeNull();
  });

  it("is visible when modalShow is true", () => {
    const { getByTestId } = render(<AddProviderModal show={true} />);
    expect(getByTestId("addprovidermodal")).toBeVisible();
  });

  it("sets modalShow to false when close button is clicked", () => {
    let modalShow = true;
    const setModalShow = (value) => {
      modalShow = value;
    };
    const { getByTestId } = render(
      <AddProviderModal show={modalShow} setModalShow={setModalShow} />
    );
    const closeButton = getByTestId("close-button");
    fireEvent.click(closeButton);
    expect(modalShow).toBe(false);
  });
});
