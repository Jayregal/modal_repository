import { render } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import EditProviderPage from "Components/Templates/DataPages/EditProviderPage";

const RouterWrapper = ({ children }) => <MemoryRouter>{children}</MemoryRouter>;

describe("Test the Edit Provider Page Component", () => {
  test("it renders without crashing", () => {
    render(<EditProviderPage />, {
      wrapper: RouterWrapper,
    });
  });
});
