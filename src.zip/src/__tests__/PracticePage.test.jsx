import { render, cleanup, fireEvent } from "@testing-library/react";
import PracticePage from "Components/Pages/PracticePage";
import ListItem from "Components/UI/Atoms/ListItem";
import practiceListData from "./mockdata/mockPracticeSummary.json";

afterEach(cleanup);

describe("Test the Practice Page Component", () => {
  test("it renders without crashing", () => {
    const clickHandler = jest.fn();
    render(
      <PracticePage
        practiceListData={practiceListData}
        titleHandler={clickHandler}
      />
    );
  });

  test("test clickHandler event", () => {
    const onItemClicked = jest.fn();
    const { getByTestId } = render(
      <ListItem
        practiceListData={practiceListData}
        onItemClicked={onItemClicked}
        dataList={practiceListData}
        id={practiceListData.practiceId}
        name={practiceListData.practiceName}
      />
    );
    const button = getByTestId("practiceNameDropDown");
    fireEvent.click(button);
    expect(onItemClicked).toHaveBeenCalled();
  });
});
