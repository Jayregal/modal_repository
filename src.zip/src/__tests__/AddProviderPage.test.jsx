import { render, cleanup } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import AddProviderPage from "Components/Templates/DataPages/AddProviderPage";

const RouterWrapper = ({ children }) => <MemoryRouter>{children}</MemoryRouter>;

afterEach(cleanup);

describe("Test the Add Provider Component", () => {
  test("it should renders without crashing", () => {
    render(<AddProviderPage />, {
      wrapper: RouterWrapper,
    });
  });
});
