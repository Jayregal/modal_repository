import { render } from "@testing-library/react";
import AddLocationModalPage from "Components/Templates/DataPages/AddLocationModalPage";

describe("Test the Contact Information Component", () => {
  test("it renders without crashing", () => {
    render(<AddLocationModalPage />);
  });
});
