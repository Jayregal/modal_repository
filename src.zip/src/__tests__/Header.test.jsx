import { cleanup, render, screen } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import Header from "Components/UI/Organisms/Header/Header";
import cookies from "js-cookie";

const RouterWrapper = ({ children }) => <MemoryRouter>{children}</MemoryRouter>;

afterEach(cleanup);

describe("Test the Header Component", () => {
  test("it renders without crashing", () => {
    render(<Header pmName={name} />, {
      wrapper: RouterWrapper,
    });
  });

  test("renders logo text in the document", () => {
    render(<Header pmName={name} />, {
      wrapper: RouterWrapper,
    });
    const linkElement = screen.getByTestId("logotext");
    expect(linkElement).toBeInTheDocument();
  });

  it("should redirect to the login page on sign out", () => {
    const spy = jest.spyOn(window.location, "href", "set");
    const { getByText } = render(<Header pmName="Jane Doe" />, {
      wrapper: RouterWrapper,
    });
    const signOutButton = getByText("Sign Out");
    signOutButton.click();
    expect(spy).toHaveBeenCalledWith(
      `${process.env.REACT_APP_SERVER_URL2}/adfs/ls/idpinitiatedSignOn.aspx?loginToRp=sentara.id`
    );
  });

  it("should remove the access cookie on sign out", () => {
    const spy = jest.spyOn(cookies, "remove");
    const { getByText } = render(<Header pmName="Jane Doe" />, {
      wrapper: RouterWrapper,
    });
    const signOutButton = getByText("Sign Out");
    signOutButton.click();
    expect(spy).toHaveBeenCalledWith("access");
  });
});
