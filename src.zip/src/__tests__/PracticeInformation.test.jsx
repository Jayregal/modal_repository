import { render, screen, cleanup } from "@testing-library/react";
import PracticeInformation from "Components/Templates/PracticeInformation/PracticeInformation";
import practiceInformationData from "./mockdata/mockPracticeInformation.json";
import locationInformationData from "./mockdata/mockLocation.json";
import { MemoryRouter } from "react-router-dom";
import ErrorServer from "Components/Hooks/Error404";

const RouterWrapper = ({ children }) => <MemoryRouter>{children}</MemoryRouter>;

afterEach(cleanup);

describe("Test the Practice Information Component", () => {
  test("it renders correctly", () => {
    render(
      <PracticeInformation
        practiceInformationData={practiceInformationData[0]}
        locationInformationData={locationInformationData[0]}
        locationTitle={locationInformationData[0].locationName}
        address={locationInformationData[0].street1}
        city={locationInformationData[0].city}
        state={locationInformationData[0].state}
        zipCode={locationInformationData[0].zipCode}
        phoneNumber={locationInformationData[0].phoneNumber}
      />,
      {
        wrapper: RouterWrapper,
      }
    );
  });

  test("it checks branches with Name Data", () => {
    render(
      <PracticeInformation
        practiceInformationData={practiceInformationData[0]}
        locationInformationData={locationInformationData[0]}
        locationTitle={locationInformationData[0].locationName}
        address={locationInformationData[0].street1}
        city={locationInformationData[0].city}
        state={locationInformationData[0].state}
        zipCode={locationInformationData[0].zipCode}
        phoneNumber={locationInformationData[0].phoneNumber}
      />,
      {
        wrapper: RouterWrapper,
      }
    );
    const nameElement4 = screen.getAllByTestId("NameData");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with out Name data", () => {
    render(
      <PracticeInformation
        practiceInformationData={practiceInformationData[1]}
        locationInformationData={locationInformationData[1]}
        locationTitle={locationInformationData[1].locationName}
        address={locationInformationData[1].street1}
        city={locationInformationData[1].city}
        state={locationInformationData[1].state}
        zipCode={locationInformationData[1].zipCode}
        phoneNumber={locationInformationData[1].phoneNumber}
      />,
      {
        wrapper: RouterWrapper,
      }
    );
    const nameElement4 = screen.getAllByTestId("NoNameData");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with Tin Data", () => {
    render(
      <PracticeInformation
        practiceInformationData={practiceInformationData[0]}
        locationInformationData={locationInformationData[0]}
        locationTitle={locationInformationData[0].locationName}
        address={locationInformationData[0].street1}
        city={locationInformationData[0].city}
        state={locationInformationData[0].state}
        zipCode={locationInformationData[0].zipCode}
        phoneNumber={locationInformationData[0].phoneNumber}
      />,
      {
        wrapper: RouterWrapper,
      }
    );
    const nameElement4 = screen.getAllByTestId("TinData");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with out Tin data", () => {
    render(
      <PracticeInformation
        practiceInformationData={practiceInformationData[1]}
        locationInformationData={locationInformationData[1]}
        locationTitle={locationInformationData[1].locationName}
        address={locationInformationData[1].street1}
        city={locationInformationData[1].city}
        state={locationInformationData[1].state}
        zipCode={locationInformationData[1].zipCode}
        phoneNumber={locationInformationData[1].phoneNumber}
      />,
      {
        wrapper: RouterWrapper,
      }
    );
    const nameElement4 = screen.getAllByTestId("NoTinData");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with Npi Data", () => {
    render(
      <PracticeInformation
        practiceInformationData={practiceInformationData[0]}
        locationInformationData={locationInformationData[0]}
        locationTitle={locationInformationData[0].locationName}
        address={locationInformationData[0].street1}
        city={locationInformationData[0].city}
        state={locationInformationData[0].state}
        zipCode={locationInformationData[0].zipCode}
        phoneNumber={locationInformationData[0].phoneNumber}
      />,
      {
        wrapper: RouterWrapper,
      }
    );
    const nameElement4 = screen.getAllByTestId("NpiData");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with out Tin data", () => {
    render(
      <PracticeInformation
        practiceInformationData={practiceInformationData[1]}
        locationInformationData={locationInformationData[1]}
        locationTitle={locationInformationData[1].locationName}
        address={locationInformationData[1].street1}
        city={locationInformationData[1].city}
        state={locationInformationData[1].state}
        zipCode={locationInformationData[1].zipCode}
        phoneNumber={locationInformationData[1].phoneNumber}
      />,
      {
        wrapper: RouterWrapper,
      }
    );
    const nameElement4 = screen.getAllByTestId("NoNpiData");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with Emr Data", () => {
    render(
      <PracticeInformation
        practiceInformationData={practiceInformationData[0]}
        locationInformationData={locationInformationData[0]}
        locationTitle={locationInformationData[0].locationName}
        address={locationInformationData[0].street1}
        city={locationInformationData[0].city}
        state={locationInformationData[0].state}
        zipCode={locationInformationData[0].zipCode}
        phoneNumber={locationInformationData[0].phoneNumber}
      />,
      {
        wrapper: RouterWrapper,
      }
    );
    const nameElement4 = screen.getAllByTestId("EmrData");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with out Emr data", () => {
    render(
      <PracticeInformation
        practiceInformationData={practiceInformationData[1]}
        locationInformationData={locationInformationData[1]}
        locationTitle={locationInformationData[1].locationName}
        address={locationInformationData[1].street1}
        city={locationInformationData[1].city}
        state={locationInformationData[1].state}
        zipCode={locationInformationData[1].zipCode}
        phoneNumber={locationInformationData[1].phoneNumber}
      />,
      {
        wrapper: RouterWrapper,
      }
    );
    const nameElement4 = screen.getAllByTestId("NoEmrData");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with Tele health Data", () => {
    render(
      <PracticeInformation
        practiceInformationData={practiceInformationData[0]}
        locationInformationData={locationInformationData[0]}
        locationTitle={locationInformationData[0].locationName}
        address={locationInformationData[0].street1}
        city={locationInformationData[0].city}
        state={locationInformationData[0].state}
        zipCode={locationInformationData[0].zipCode}
        phoneNumber={locationInformationData[0].phoneNumber}
      />,
      {
        wrapper: RouterWrapper,
      }
    );
    const nameElement4 = screen.getAllByTestId("TelehealthData");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with out Tele health data", () => {
    render(
      <PracticeInformation
        practiceInformationData={practiceInformationData[1]}
        locationInformationData={locationInformationData[1]}
        locationTitle={locationInformationData[1].locationName}
        address={locationInformationData[1].street1}
        city={locationInformationData[1].city}
        state={locationInformationData[1].state}
        zipCode={locationInformationData[1].zipCode}
        phoneNumber={locationInformationData[1].phoneNumber}
      />,
      {
        wrapper: RouterWrapper,
      }
    );
    const nameElement4 = screen.getAllByTestId("NoTelehealthData");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with Specialty Data", () => {
    render(
      <PracticeInformation
        practiceInformationData={practiceInformationData[0]}
        locationInformationData={locationInformationData[0]}
        locationTitle={locationInformationData[0].locationName}
        address={locationInformationData[0].street1}
        city={locationInformationData[0].city}
        state={locationInformationData[0].state}
        zipCode={locationInformationData[0].zipCode}
        phoneNumber={locationInformationData[0].phoneNumber}
      />,
      {
        wrapper: RouterWrapper,
      }
    );
    const nameElement4 = screen.getAllByTestId("SpecialtyData");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with out Specialty data", () => {
    render(
      <PracticeInformation
        practiceInformationData={practiceInformationData[1]}
        locationInformationData={locationInformationData[1]}
        locationTitle={locationInformationData[1].locationName}
        address={locationInformationData[1].street1}
        city={locationInformationData[1].city}
        state={locationInformationData[1].state}
        zipCode={locationInformationData[1].zipCode}
        phoneNumber={locationInformationData[1].phoneNumber}
      />,
      {
        wrapper: RouterWrapper,
      }
    );
    const nameElement4 = screen.getAllByTestId("NoSpecialtyData");
    expect(nameElement4).toHaveLength(1);
  });

  test("it checks branches with Accepting new medicaid patient", () => {
    render(
      <PracticeInformation
        practiceInformationData={practiceInformationData[0]}
        locationInformationData={locationInformationData[0]}
        locationTitle={locationInformationData[0].locationName}
        address={locationInformationData[0].street1}
        city={locationInformationData[0].city}
        state={locationInformationData[0].state}
        zipCode={locationInformationData[0].zipCode}
        phoneNumber={locationInformationData[0].phoneNumber}
      />,
      {
        wrapper: RouterWrapper,
      }
    );
    const trueValue = screen.getAllByTestId("AcceptingMedicaid");
    expect(trueValue).toHaveLength(1);
  });

  test("it checks branches with out Accepting new medicaid patient", () => {
    render(
      <PracticeInformation
        practiceInformationData={practiceInformationData[1]}
        locationInformationData={locationInformationData[1]}
        locationTitle={locationInformationData[1].locationName}
        address={locationInformationData[1].street1}
        city={locationInformationData[1].city}
        state={locationInformationData[1].state}
        zipCode={locationInformationData[1].zipCode}
        phoneNumber={locationInformationData[1].phoneNumber}
      />,
      {
        wrapper: RouterWrapper,
      }
    );
    const falseValue = screen.getAllByTestId("NotAcceptingMedicaid");
    expect(falseValue).toHaveLength(1);
  });

  test("it checks branches with Accepting new patient", () => {
    render(
      <PracticeInformation
        practiceInformationData={practiceInformationData[0]}
        locationInformationData={locationInformationData[0]}
        locationTitle={locationInformationData[0].locationName}
        address={locationInformationData[0].street1}
        city={locationInformationData[0].city}
        state={locationInformationData[0].state}
        zipCode={locationInformationData[0].zipCode}
        phoneNumber={locationInformationData[0].phoneNumber}
      />,
      {
        wrapper: RouterWrapper,
      }
    );
    const trueValue = screen.getAllByTestId("AcceptingNewPatients");
    expect(trueValue).toHaveLength(1);
  });

  test("it checks branches with out Accepting new patient", () => {
    render(
      <PracticeInformation
        practiceInformationData={practiceInformationData[1]}
        locationInformationData={locationInformationData[1]}
        locationTitle={locationInformationData[1].locationName}
        address={locationInformationData[1].street1}
        city={locationInformationData[1].city}
        state={locationInformationData[1].state}
        zipCode={locationInformationData[1].zipCode}
        phoneNumber={locationInformationData[1].phoneNumber}
      />,
      {
        wrapper: RouterWrapper,
      }
    );
    const falseValue = screen.getAllByTestId("NotAcceptingNewPatients");
    expect(falseValue).toHaveLength(1);
  });

  test("it checks branches with Lower age limit", () => {
    render(
      <PracticeInformation
        practiceInformationData={practiceInformationData[0]}
        locationInformationData={locationInformationData[0]}
        locationTitle={locationInformationData[0].locationName}
        address={locationInformationData[0].street1}
        city={locationInformationData[0].city}
        state={locationInformationData[0].state}
        zipCode={locationInformationData[0].zipCode}
        phoneNumber={locationInformationData[0].phoneNumber}
      />,
      {
        wrapper: RouterWrapper,
      }
    );
    const trueValue = screen.getAllByTestId("LowerAgeLimitData");
    expect(trueValue).toHaveLength(1);
  });

  test("it checks branches with out lower age limit", () => {
    render(
      <PracticeInformation
        practiceInformationData={practiceInformationData[1]}
        locationInformationData={locationInformationData[1]}
        locationTitle={locationInformationData[1].locationName}
        address={locationInformationData[1].street1}
        city={locationInformationData[1].city}
        state={locationInformationData[1].state}
        zipCode={locationInformationData[1].zipCode}
        phoneNumber={locationInformationData[1].phoneNumber}
      />,
      {
        wrapper: RouterWrapper,
      }
    );
    const falseValue = screen.getAllByTestId("noLowerAgeLimitData");
    expect(falseValue).toHaveLength(1);
  });

  test("it checks branches with location data", () => {
    render(
      <PracticeInformation
        practiceInformationData={practiceInformationData[0]}
        locationInformationData={locationInformationData[0]}
        locationTitle={locationInformationData[0].locationName}
        address={locationInformationData[0].street1}
        city={locationInformationData[0].city}
        state={locationInformationData[0].state}
        zipCode={locationInformationData[0].zipCode}
        phoneNumber={locationInformationData[0].phoneNumber}
      />,
      {
        wrapper: RouterWrapper,
      }
    );
    const trueValue = screen.getAllByTestId("LocationData");
    expect(trueValue).toHaveLength(1);
  });

  test("it checks branches with out location data", () => {
    render(
      <PracticeInformation
        practiceInformationData={practiceInformationData[1]}
        locationInformationData={locationInformationData[1]}
        locationTitle={locationInformationData[1].locationName}
        address={locationInformationData[1].street1}
        city={locationInformationData[1].city}
        state={locationInformationData[1].state}
        zipCode={locationInformationData[1].zipCode}
        phoneNumber={locationInformationData[1].phoneNumber}
      />,
      {
        wrapper: RouterWrapper,
      }
    );
    const falseValue = screen.getAllByTestId("NoLocationData");
    expect(falseValue).toHaveLength(1);
  });

  test("it checks branches with phone number data", () => {
    render(
      <PracticeInformation
        practiceInformationData={practiceInformationData[0]}
        locationInformationData={locationInformationData[0]}
        locationTitle={locationInformationData[0].locationName}
        address={locationInformationData[0].street1}
        city={locationInformationData[0].city}
        state={locationInformationData[0].state}
        zipCode={locationInformationData[0].zipCode}
        phoneNumber={locationInformationData[0].phoneNumber}
      />,
      {
        wrapper: RouterWrapper,
      }
    );
    const trueValue = screen.getAllByTestId("PhoneNumber");
    expect(trueValue).toHaveLength(1);
  });

  test("it checks branches with out phone number data", () => {
    render(
      <PracticeInformation
        practiceInformationData={practiceInformationData[1]}
        locationInformationData={locationInformationData[1]}
        locationTitle={locationInformationData[1].locationName}
        address={locationInformationData[1].street1}
        city={locationInformationData[1].city}
        state={locationInformationData[1].state}
        zipCode={locationInformationData[1].zipCode}
        phoneNumber={locationInformationData[1].phoneNumber}
      />,
      {
        wrapper: RouterWrapper,
      }
    );
    const falseValue = screen.getAllByTestId("NoPhoneNumber");
    expect(falseValue).toHaveLength(1);
  });

  test("it checks branches with fax number data", () => {
    render(
      <PracticeInformation
        practiceInformationData={practiceInformationData[0]}
        locationInformationData={locationInformationData[0]}
        locationTitle={locationInformationData[0].locationName}
        address={locationInformationData[0].street1}
        city={locationInformationData[0].city}
        state={locationInformationData[0].state}
        zipCode={locationInformationData[0].zipCode}
        phoneNumber={locationInformationData[0].phoneNumber}
      />,
      {
        wrapper: RouterWrapper,
      }
    );
    const trueValue = screen.getAllByTestId("FaxNumber");
    expect(trueValue).toHaveLength(1);
  });

  test("it checks branches with out fax number data", () => {
    render(
      <PracticeInformation
        practiceInformationData={practiceInformationData[1]}
        locationInformationData={locationInformationData[1]}
        locationTitle={locationInformationData[1].locationName}
        address={locationInformationData[1].street1}
        city={locationInformationData[1].city}
        state={locationInformationData[1].state}
        zipCode={locationInformationData[1].zipCode}
        phoneNumber={locationInformationData[1].phoneNumber}
      />,
      {
        wrapper: RouterWrapper,
      }
    );
    const falseValue = screen.getAllByTestId("NoFaxNumber");
    expect(falseValue).toHaveLength(1);
  });

  test("it checks branches with scheduling number data", () => {
    render(
      <PracticeInformation
        practiceInformationData={practiceInformationData[0]}
        locationInformationData={locationInformationData[0]}
        locationTitle={locationInformationData[0].locationName}
        address={locationInformationData[0].street1}
        city={locationInformationData[0].city}
        state={locationInformationData[0].state}
        zipCode={locationInformationData[0].zipCode}
        phoneNumber={locationInformationData[0].phoneNumber}
      />,
      {
        wrapper: RouterWrapper,
      }
    );
    const trueValue = screen.getAllByTestId("SchedulingNumber");
    expect(trueValue).toHaveLength(1);
  });

  test("it checks branches with out scheduling number data", () => {
    render(
      <PracticeInformation
        practiceInformationData={practiceInformationData[1]}
        locationInformationData={locationInformationData[1]}
        locationTitle={locationInformationData[1].locationName}
        address={locationInformationData[1].street1}
        city={locationInformationData[1].city}
        state={locationInformationData[1].state}
        zipCode={locationInformationData[1].zipCode}
        phoneNumber={locationInformationData[1].phoneNumber}
      />,
      {
        wrapper: RouterWrapper,
      }
    );
    const falseValue = screen.getAllByTestId("NoSchedulingNumber");
    expect(falseValue).toHaveLength(1);
  });

  it("should render the ErrorServer component if isServerError is true", () => {
    const { getByTestId } = render(<ErrorServer />);
    const errorServer = getByTestId("error-server");
    expect(errorServer).toBeInTheDocument();
  });

  it("should not render the ErrorServer component if isServerError is false", () => {
    const { queryByTestId } = render(<ErrorServer />);
    const errorServer = queryByTestId("error-server1");
    expect(errorServer).not.toBeInTheDocument();
  });
});
