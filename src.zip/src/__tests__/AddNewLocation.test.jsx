import React from "react";
import { render, fireEvent } from "@testing-library/react";
import AddNewLocation from "Components/UI/Organisms/AddNewLocation";

describe("AddNewLocation", () => {
  it("should render the component", () => {
    const { getByTestId } = render(<AddNewLocation />);
    expect(getByTestId("address-input")).toBeInTheDocument();
  });

  it("should update the locationtype state when a button is clicked", () => {
    const newHandleSelect = jest.fn();
    const { getByTestId } = render(
      <AddNewLocation newHandleSelect={newHandleSelect} />
    );
    const primaryButton = getByTestId("primary-location-button");
    fireEvent.click(primaryButton);
    expect(newHandleSelect).toHaveBeenCalledWith(
      expect.objectContaining({ target: { value: "1" } }),
      undefined
    );
  });

  it("should update the provider state when a radio button is clicked", () => {
    const handleChangeProvider = jest.fn();
    const { getByTestId } = render(
      <AddNewLocation handleChangeProvider={handleChangeProvider} />
    );
    const yesRadioButton = getByTestId("yes-provider-radio");
    fireEvent.click(yesRadioButton);
    expect(handleChangeProvider).toHaveBeenCalledWith(
      expect.objectContaining({ target: { value: "yes" } }),
      undefined,
      true
    );
  });
});
