import { render } from "@testing-library/react";
import practiceListData from "./mockdata/mockPracticeSummary.json";
import PracticeBanner from "Components/UI/Organisms/PracticeBanner/PracticeBanner";

describe("Test the Practice Banner Component", () => {
  test("it renders without crashing", () => {
    render(<PracticeBanner practiceListData={practiceListData} />);
  });
});
