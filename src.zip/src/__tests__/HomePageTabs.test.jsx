import { render } from "@testing-library/react";
import HomePageTabs from "Components/Templates/Tabs/HomePageTabs";
import practiceListData from "./mockdata/mockPracticeSummary.json";
import locationListData from "./mockdata/mockLocation.json";

describe("Test the Home Page Tabs Component", () => {
  test("it renders without crashing", () => {
    render(
      <HomePageTabs
        practiceListData={practiceListData}
        locationListData={locationListData}
      />
    );
  });
});
