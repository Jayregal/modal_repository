import { render } from "@testing-library/react";
import DropdownList from "Components/UI/Molecules/Dropdownlist";

describe("Test the Practice Dropdownlist Component", () => {
  test("renders without crashing", () => {
    render(<DropdownList />);
  });
});
