import React from "react";
import "./App.css";
import Authentication from "Components/Pages/Authentication";

function App() {
  return (
    <>
      <Authentication />
    </>
  );
}

export default App;
