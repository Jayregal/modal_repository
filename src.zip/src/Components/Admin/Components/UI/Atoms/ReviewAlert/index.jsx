import React from "react";
import { Alert } from "react-bootstrap";

function ReviewAlert({
  ApprovalcloseIcon,
  ApprovalIcon,
  AlertText,
  ALertHandleClick,
  variant
}) {
  return (
    <React.Fragment>
      <Alert variant={variant} data-testid="practiceInfoupdated">
        <img src={ApprovalIcon} alt="Updated Icon" className="updated-icon" />
        {AlertText}
        <button
          onClick={ALertHandleClick}
          className="close-icon-button1"
          data-testid="practiceInfoupdatedclose"
        >
          <img
            src={ApprovalcloseIcon}
            alt="Updated Icon"
            className="updated-icon"
          />
        </button>
      </Alert>
    </React.Fragment>
  );
}

export default ReviewAlert;
