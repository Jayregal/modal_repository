import React, { useState } from "react";
import Pagination from "../../../../../Templates/ProviderList/Pagination";

export default function AdminLocationList({ locationListData }) {
  const [currentPage, setCurrentPage] = useState(1);
  const [recordsPerPage] = useState(10);
  const sortedData = locationListData.sort((a) => {
    if (a.status === "Pending") {
      return -1;
    } else {
      return 0;
    }
  });

  const indexOfLastRecord = currentPage * recordsPerPage;
  const indexOfFirstRecord = indexOfLastRecord - recordsPerPage;
  const currentRecords =
    sortedData?.length > 0 &&
    sortedData?.slice(indexOfFirstRecord, indexOfLastRecord);
  const nPages = Math.ceil(sortedData?.length / recordsPerPage);
  console.log("lic", currentRecords);

  return (
    <>
      <div className="manage-location-table">
        <div className="table-responsive">
          <table className="table">
            <thead>
              <tr>
                <th className="location_number">Location Number</th>
                <th className="location_name">Location Name</th>
                <th className="location_name">Address</th>
                <th className="phone-head other_number">Phone Number</th>
                <th className="phone-head1 other_number">Fax Number</th>
                <th className="phone-head2 other_number">Scheduling Number</th>
                <th className="phone-head1 location_date">Start Date</th>
                <th className="phone-head1 location_date">Term Date</th>
                <th>Action</th>
              </tr>
            </thead>
            {sortedData?.length > 0 && (
              <tbody data-testid="ProviderData">
                {currentRecords?.map((location) => (
                  <tr key={location?.id}>
                    {console.log("lic", location)}
                    <td data-testid="locationNum" className="locationNum">
                      {location?.locationNumber}
                    </td>
                    <td data-testid="locationName">{location?.locationName}</td>
                    <td data-testid="PrimaryLocation">{`${location?.street1} ${
                      location?.street2 ? location?.street2 : ""
                    } ${location?.street3 ? location?.street3 : ""}, ${
                      location?.city
                    }, ${location?.state} ${location?.zipCode}`}</td>
                    <td>
                      {
                        location?.phoneNumber.find(
                          (phone) => phone.phoneTypeId === 1
                        )?.number
                      }
                    </td>
                    <td>
                      {
                        location?.phoneNumber.find(
                          (phone) => phone.phoneTypeId === 4
                        )?.number
                      }
                    </td>
                    <td>
                      {
                        location?.phoneNumber.find(
                          (phone) => phone.phoneTypeId === 5
                        )?.number
                      }
                    </td>
                    <td className="delete-action">
                      {/* {location?.status !== "Pending" &&
                    location?.isDeleted !== true && (
                    <img src={deleteIcon} alt="add icon" />
                  )} */}
                    </td>
                  </tr>
                ))}
              </tbody>
            )}
            {/* </Table> */}
          </table>
        </div>
        {locationListData?.length > 0 && (
          <Pagination
            nPages={nPages}
            currentPage={currentPage}
            setCurrentPage={setCurrentPage}
            data-testid="PaginationPage"
          />
        )}
      </div>
    </>
  );
}
