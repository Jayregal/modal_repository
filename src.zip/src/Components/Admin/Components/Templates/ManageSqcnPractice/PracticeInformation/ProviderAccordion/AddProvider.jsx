import React, { useState, useEffect } from "react";
import { Button } from "react-bootstrap";
import { Table } from "react-bootstrap";
import { Link } from "react-router-dom";
import plusIcon from "../../../../../../../images/plus_icon.svg";

//import icon from "../images/Icon.svg";
import deleteIcon from "../images/delete_icon.svg";
// import sortIcon from "../images/";
import AddProviderModal from "./AddProviderModal";
import ViewProvider from "./ViewProvider";
import CreateNewProviderAdminNeweAdmin from "Components/Templates/DataPages/CreateProviderPageAdmin";

export const stillAtLocation = (termDate) => {
  if (termDate === null) {
    return "Yes";
  } else {
    const today = new Date();
    const termDateObj = new Date(termDate);

    if (termDateObj > today) {
      return "Yes";
    } else {
      return "No";
    }
  }
};

const AddProvider = ({
  personRoleName,
  setContactInformationData,
  locationPayload,
  setLocationPayload,
  contactInformationData,
  addFlow,
}) => {
  const [modalShow, setModalShow] = useState(false);
  const [viewProviderIdModal, setViewProviderIdModal] = useState(false); // State to hold the provider ID for ViewProvider component

  const decodeTokenId = window.localStorage.getItem("decodeToken");
  const [creatNpi, setCreatNpi] = useState();

  const [updatedProviderList, setUpdatedProviderList] = useState([]);

  const [filteredProviderList, setFilteredProviderList] = useState([]);

  const handleDelete = (providerId) => {
    const updatedProviderList2 = filteredProviderList.filter(
      (provider) => provider.localId !== providerId
    );
    setUpdatedProviderList(updatedProviderList2);

    // setFilteredProviderList(updatedProviderList2);
  };

  useEffect(() => {
    if (updatedProviderList.length > 0) {
      updatedProviderList.forEach((item, i) => {
        item.localId = i + 1;
      });
      setFilteredProviderList(updatedProviderList);
    }
  }, [updatedProviderList]);

  return (
    <>
      <div className="w-100 d-flex position-relative">
        <div className="w-100 text-end">
          <Button
            data-testid="addprovider"
            variant="primary"
            onClick={() => {
              setModalShow(true);
            }}
            className="rounded-pill add_new_practice btn btn-primary"
          //disabled={viewProviderIdModal ? true : false}
          >
            <img src={plusIcon} alt="Search Icon" />
            Add New Provider
          </Button>
        </div>
        {modalShow && (
          <AddProviderModal
            data-testid="addprovidermodal"
            show={modalShow}
            onHide={() => setModalShow(false)}
            isAdmin={true}
            setViewProviderId={setViewProviderIdModal}
            showCreatNpi={setCreatNpi}
          />
        )}
      </div>

      {filteredProviderList.length > 0 && (
        <div className="provider-list-table">
          <Table data-testid="providerlisttable">
            <thead>
              <tr>
                <th className="provider_Column">NPI</th>
                <th className="provider_Column">Full name</th>
                <th>isPrimary</th>
                <th className="provider_Column1">Primary Location Name</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody data-testid="ProviderData">
              {filteredProviderList?.map((provider) => {
                return (
                  <tr className={"tr_table"} key={provider?.localId}>
                    <td data-testid="providerPrimaryNpi">
                      {provider?.person?.npi}
                    </td>

                    <td data-testid="providerName">
                      <Link key={provider?.id} onClick={() => { }}>
                        {provider?.person.firstName}&nbsp;
                        {provider?.person?.middleName}
                        &nbsp;
                        {provider?.person?.lastName}
                      </Link>
                    </td>
                    <td
                      className="still-at-locations"
                      data-testid="providerStillAtLocation"
                    >
                      {provider?.location?.locationNumber === 1 ? "Yes" : "No"}
                    </td>

                    {provider?.location?.street1 ? (
                      <td data-testid="providerPrimaryLocation">
                        {`${provider?.location?.street1 ?? ""} ${provider?.location?.street2 ?? ""
                        }, ${provider?.location?.city ?? ""}, 
                          ${provider?.location?.state ?? ""} ${provider?.location?.zipCode ?? ""
                      }`}
                      </td>
                    ) : (
                      <td data-testid="providerPrimaryLocation">--</td>
                    )}
                    <>
                      <td className="text-center" data-testid="providerStatus">
                        <button
                          type="button"
                          className="icon_style"
                          onClick={() => handleDelete(provider.localId)}
                        >
                          <img src={deleteIcon} alt="Sort Icon" />
                        </button>
                      </td>
                    </>
                  </tr>
                );
              })}
            </tbody>
          </Table>
          {/* {activeProviders?.length > 0 && (
              <Pagination
                nPages={nPages}
                currentPage={currentPage}
                setCurrentPage={setCurrentPage}
                setIsCheckAll={setIsCheckAll}
                isCheckAll={isCheckAll}
                isCheck={isCheck}
                selectedPractice={selectedPracticeId}
                data-testid="PaginationPage"
              />
            )} */}
        </div>
      )}
      {viewProviderIdModal ? (
        <ViewProvider
          practiceTitle={window.localStorage.getItem("practiceTitle")}
          selectedPracticeId={window.localStorage.getItem(
            "selectedPracticeIdByAdmin"
          )}
          // practiceManagerId={window.localStorage.getItem("practiceManagerId")}
          practiceManagerId={
            decodeTokenId?.id ||
            window.localStorage.getItem("practiceManagerId")
          }
          personRoleName={personRoleName}
          locationPayload={locationPayload}
          setLocationPayload={setLocationPayload}
          setContactInformationData={setContactInformationData}
          contactInformationData={contactInformationData}
          addFlow={addFlow}
          updatedProviderList={updatedProviderList}
          setViewProviderIdModal={setViewProviderIdModal}
          setUpdatedProviderList={setUpdatedProviderList}
        />
      ) : null}
      {creatNpi ? (
        <CreateNewProviderAdminNeweAdmin
          practiceTitle={window.localStorage.getItem("practiceTitle")}
          practiceManagerId={
            decodeTokenId?.id ||
            window.localStorage.getItem("practiceManagerId")
          }
          selectedPracticeId={window.localStorage.getItem(
            "selectedPracticeIdByAdmin"
          )}
          locationPayload={locationPayload}
          setLocationPayload={setLocationPayload}
          setContactInformationData={setContactInformationData}
          contactInformationData={contactInformationData}
          setUpdatedProviderList={setUpdatedProviderList}
          setViewProviderIdModal={setViewProviderIdModal}
          updatedProviderList={updatedProviderList}
          setCreatNpi={setCreatNpi}
        />
      ) : null}
    </>
  );
};

export default AddProvider;
