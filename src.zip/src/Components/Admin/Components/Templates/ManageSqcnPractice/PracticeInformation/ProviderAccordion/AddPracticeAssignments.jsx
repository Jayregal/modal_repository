import React from "react";
import { Modal, Row, Col } from "react-bootstrap";

const AddPracticeAssignments = (props) => {
  const curatedProvidersList = [];
  return (
    <Modal
      size="md"
      aria-labelledby="contained-modal-title-vcenter"
      centered
      className="add-provider-modal"
      data-testid="addprovidermodal"
    >
      <Modal.Header closeButton>
        <Modal.Title id="contained-modal-title-vcenter">
          Add New Provider
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <p className="">Search Provider by NPI ID</p>
        <div className="providers-result" data-testid="providerresult">
          {curatedProvidersList.map((item) => {
            return (
              <div
                key={item.id}
                className="provider-search-list"
                data-testid="providersearchresult"
              >
                <Row>
                  <Col md={4} xs={12} data-testid="providerName">
                    {item?.firstName} {item?.lastName}
                  </Col>
                  <Col md={2} xs={12} data-testid="providerTitle">
                    {item?.titleType[0]?.title
                      ? item?.titleType[0]?.title
                      : "--"}
                  </Col>
                  <Col
                    md={6}
                    xs={12}
                    className="provider-result-email"
                    data-testid="providerEmail"
                  >
                    {item?.email[0]?.emailAddress
                      ? item?.email[0]?.emailAddress
                      : "--"}
                  </Col>
                </Row>
              </div>
            );
          })}
        </div>
      </Modal.Body>
      <Modal.Footer className="justify-content-center">
        <button
          onClick={props.onHide}
          className="white-btn"
          data-testid="close-button"
        >
          Cancel
        </button>
        <button
          onClick={props.onHide}
          // disabled={curatedProvidersList.length >= 1 ? false : true}
          disabled
          className="blue-btn"
          data-testid="AddproviderButton"
        >
          Add Location
        </button>
      </Modal.Footer>
    </Modal>
  );
};

export default AddPracticeAssignments;
