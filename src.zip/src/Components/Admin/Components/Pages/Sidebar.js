import React from "react";
import {
  CDBSidebar,
  CDBSidebarContent,
  CDBSidebarHeader,
  CDBSidebarMenu,
  CDBSidebarMenuItem,
} from "cdbreact";
import { NavLink } from "react-router-dom";

const Sidebar = () => {
  return (
    <div
      className={"app"}
      style={{ display: "flex", height: "100%", overflow: "scroll initial" }}
    >
      <CDBSidebar textColor="#fff" backgroundColor="#005E86">
        <CDBSidebarHeader prefix={<i className="fa fa-bars fa-large"></i>}>
          <a
            href="/sqcn-admin"
            className="text-decoration-none"
            style={{ color: "inherit" }}
          >
            Sentara SQCN
          </a>
        </CDBSidebarHeader>

        <CDBSidebarContent className="sidebar-content">
          <CDBSidebarMenu>
            <NavLink exact to="/sqcn-admin" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="home">Home</CDBSidebarMenuItem>
            </NavLink>
            <NavLink exact to="/manage-sqcn-practice" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="user">Manage SQCN Practice</CDBSidebarMenuItem>
            </NavLink>
            <NavLink exact to="/manage-ppd-access" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="key">Manage PPD Access</CDBSidebarMenuItem>
            </NavLink>
            <NavLink exact to="/npi-search" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="search">NPI Search</CDBSidebarMenuItem>
            </NavLink>
          </CDBSidebarMenu>
        </CDBSidebarContent>
      </CDBSidebar>
    </div>
  );
};

export default Sidebar;
