/* eslint-disable indent */
/* eslint-disable no-unsafe-optional-chaining */
import React, { useState, useEffect } from "react";
import { Container, Col, Row, Form, Table, Button } from "react-bootstrap";
import { firstLetterOfTwo } from "utils";
// import { Link } from "react-router-dom";
// import practiceIcon from "./images/Icon-b-practice.svg";
// import providerListIcon from "./images/Icon-b-provider-list.svg";
// import userIcon from "./images/Icon-b-user.svg";
import sortIcon from "./images/Sort_arrow.svg";
// import editIcon from "./images/Icon-b-edit.svg";
import dropIcon from "./images/dropdownIcon.svg";
import labels from "Static/Dictionary.json";
import DatePicker from "react-datepicker";
import moment from "moment/moment";
import "react-datepicker/dist/react-datepicker.css";
import { useFetch } from "Components/Hooks/Fetch";
// import { useNavigate } from "react-router-dom";
import * as yup from "yup";
import { useFormik } from "formik";
import cookies from "js-cookie";
import EditSpecialtyPage from "../DataPages/EditSpecialtyPage";
import AddLocationModalPageAdmin from "../DataPages/AddLocationModalPageAdmin";
import jwt_decode from "jwt-decode";
import DatePickerIcon from "./images/Icon-date.svg";
import closeIcon from "./images/close-icon.svg";
import updatedIcon from "./images/Icon-updated.svg";
import { Alert } from "react-bootstrap";
import { formatDateByTimeZone } from "Static/format";
import { EMAIL_REGEX,ALPHABETS_AND_SPECIAL_CHARS_REGEX } from "utils";

function convertLocalToUTCDate(date) {
  return date ? new Date(date) : null;
}

const CreateNewProviderAdminNew = ({
  practiceTitle,
  providerSummary,
  //   id,
  selectedPracticeId,
  practiceManagerId,
  personRoleName,
  locationPayload,
  setLocationPayload,
  setContactInformationData,
  contactInformationData,
  setViewProviderIdModal,
  setUpdatedProviderList,
  updatedProviderList,
  setCreatNpi,
}) => {
  const [providerEdit, setProviderEdit] = useState({});
  const [providerPrefix, setProviderPrefix] = useState({
    prefixId: providerSummary?.prefixId,
  });
  const [success, setSuccess] = useState(false);
  const [providerPrefixName, setProviderPrefixName] = useState("");
  const [selectedTitle, setSelectedTitle] = useState("");
  const [sltdSpltyId, setSltdSpltyId] = useState(null);
  const [spltyName, setSpltyName] = useState(null);
  const [modalShow, setModalShow] = useState(false);
  const [newSpecialty, setNewSpecialty] = useState();
  const [errorMessage, setErrorMessage] = useState("");
  const [addLocationList, setAddLocationListData] = useState([]);
  const [searchInput, setSearchInput] = useState("");
  const [searchAddress, setSearchAddress] = useState("");
  const [searchStartDate, setSearchStartDate] = useState("");
  const [searchEndDate, setSearchEndDate] = useState("");
  const [filteredAllData, setFilteredAllData] = useState([]);
  const [sortOrder, setSortOrder] = useState("asc");
  const [primaryPracticeId, setPrimaryPracticeId] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedSuffix, setSelectedSuffix] = useState("");

  //const [hideSubmit, setHideSubmit] = useState(false);
  // const base_url = process.env.REACT_APP_SERVER_URL1;

  const base_url1 = process.env.REACT_APP_SERVER_URL;
  const { data = [] } = useFetch("/api/v1/providers/GetAllTitleTypes");
  const subscriptionKey = process.env.REACT_APP_TOKEN;
  const token = cookies.get("access");
  localStorage.getItem("selectedPracticeId") || selectedPracticeId;
  // const [showAlert, setshowAlert] = useState(false);
  const [hideData, setHideData] = useState(false);
  const decodeToken = jwt_decode(token);

  const [effectiveDate, setEffectiveDate] = useState(null);

  const [titleData, setTitleData] = useState([]);
  const [prefixData, setPrefixData] = useState([]);

  console.log("titleData", titleData);
  const prefix_mapTitles = [
    "16",
    "41",
    "24",
    "61",
    "31",
    "62",
    "63",
    "5",
    "11",
    "36",
    "1",
    "66",
    "67",
    "32",
    "68",
    "22",
    "84",
    "23",
    "45",
  ];

  const handleIdChange = (name, value) => {
    if (name === "prefixId") {
      setProviderPrefix({ prefixId: value });
    }
  };

  const fixSonar = (e) => {
    console.log("fixSonar", e, primaryPracticeId, newSpecialty, sltdSpltyId);

    setHideData(false);
    setIsLoading(false);

    setErrorMessage(false);
  };

  useEffect(() => {
    fixSonar();
  }, []);

  const handleInputChange = (e) => {
    const { value } = e.target;
    setProviderPrefixName(value);
  };

  const GetTitleDetails = () => {
    fetch(base_url1 + "/api/v1/contact/GetTitleDetails", {
      method: "GET",
      headers: new Headers({
        Authorization: "Bearer " + token,
        "Content-Type": "application/json",
        "ocp-apim-subscription-key": subscriptionKey,
      }),
    })
      .then((response) => response.json())
      .then((data) => {
        setTitleData(data?.titleTypeList || []);
        setPrefixData(data?.prefixList || []);
      });
  };

  useEffect(() => {
    const fetch = async () => {
      GetTitleDetails();
    };
    fetch();
  }, []);

  const [allLocationData, setAllLocationData] = useState([]);

  const GetLocationDetails = () => {
    fetch(base_url1 + "/api/v1/practices/GetAllLocations", {
      method: "GET",
      headers: new Headers({
        Authorization: "Bearer " + token,
        "Content-Type": "application/json",
        "ocp-apim-subscription-key": subscriptionKey,
      }),
    })
      .then((response) => response.json())
      .then((data) => {
        if (data?.length > 0) {
          setAllLocationData(data);
        }
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
      });
  };

  useEffect(() => {
    const fetch = async () => {
      GetLocationDetails();
    };
    fetch();
  }, []);

  // console.log(
  //   "cd",
  //   spltyName,
  //   newSpecialty,
  //   primaryPracticeId,
  //   providerPrefix
  // );

  const getPrefixByName = (prefixName) => {
    if (prefixData?.length > 0) {
      const prefix = prefixData?.filter(
        (item) => item.prefixName === prefixName
      );
      if (prefix.length > 0) {
        return prefix[0].id;
      }
    }
    return "";
  };

  const handlePrefixChange = (id) => {
    console.log("id", id);
    const DrId = getPrefixByName("Dr");
    const value = { ...providerPrefix, prefixId: DrId };
    setProviderPrefix(value);
    setProviderPrefixName("Dr");
  };

  useEffect(() => {
    const value = providerSummary?.practiceAssignment?.map((item) => ({
      ...item,
      isProviderTrue: item?.termDate === null ? true : false,
      isProviderFalse: item?.termDate === null ? false : true,
      isDefaultId: item?.assignmentTypeId === 1 ? true : false,
    }));
    const provider = { ...providerSummary, practiceAssignment: value };
    setProviderEdit(provider);
    providerSummary && setSelectedTitle(selectedTitle);
    providerSummary && setSelectedSuffix(selectedSuffix);
  }, [providerSummary]);
  const specialtyDetailsByspecialtype =
    providerSummary?.specialtySpecialtyType?.find(
      (item) => item?.specialtyType?.typeSpecialty === "Board Specialty1"
    );
  const firstLetters = firstLetterOfTwo(
    providerSummary?.firstName,
    providerSummary?.lastName
  );

  const [allSuffixData, setAllSuffixData] = useState([]);
  const { data: GetSuffixData } = useFetch("/api/v1/contact/GetSuffixData");
  useEffect(() => {
    if (GetSuffixData) {
      setAllSuffixData(GetSuffixData);
    }
  }, [GetSuffixData]);

  const validationSchema = yup.object({
    firstName: yup
      .string()
      .max(25, "Too Long!")
      .matches(ALPHABETS_AND_SPECIAL_CHARS_REGEX, "Name cannot contain numbers ")
      .required("First Name is required"),
    middleName: yup
      .string()
      .nullable()
      .max(25, "Too Long!")
      .matches(ALPHABETS_AND_SPECIAL_CHARS_REGEX, "Name cannot contain numbers"),
    lastName: yup
      .string()
      .max(25, "Too Long!")
      .matches(ALPHABETS_AND_SPECIAL_CHARS_REGEX, "Name cannot contain numbers ")
      .required("Last Name is required"),
    mdofficeId: yup.string().max(25, "Too Long!"),
    npi: yup
      .string()
      .required("NPI is required")
      .min(10, "NPI should be 10 digits")
      .max(10, "NPI should be 10 digits")
      .matches(/^[0-9]+$/, "Must be only digits"),
    preferredEmailAddress: yup
      .string()
      .required("Email required.")
      .matches(EMAIL_REGEX, "Invalid email format"),
     
    sentaraEmailAddress: yup.string().matches(EMAIL_REGEX, "Invalid email format"),
  });

  const formik = useFormik({
    initialValues: {
      firstName: "",
      middleName: "",
      lastName: "",
      mdofficeId: "",
      npi: "",
      preferredEmailAddress: "",
      sentaraEmailAddress: "",
      contractedSpecialtyId: "",
      contractedSpecialtyName: "",
      providersEffectiveDate: "",
      providersNameBeforeEditing: "",
    },
    validationSchema: validationSchema,
    onSubmit: (values) => {
      let contactInfo = [];
      let contactWithLocation = [];
      locationData.map((item,index) => {
        let localObject = {
          startDate: null,
          termDate: null,
          roleTypeId: 2,
          localId:index,
          isProvider:item.locationNumber===1?true:false,

          person: {
            prefixId: parseInt(providerPrefix?.prefixId),
            firstName: values?.firstName,
            middleName: values?.middleName,
            lastName: values?.lastName,
            mdofficeId: values?.mdofficeId,
            npi: values?.npi,
            preferredEmailAddress: values?.preferredEmailAddress,
            sentaraEmailAddress: values?.sentaraEmailAddress,
            updateUser: practiceManagerId,
            providersEffectiveDate: effectiveDate,
            providersNameBeforeEditing: values.providersNameBeforeEditing,
            suffix: selectedSuffix,
            IsPrimaryCare: false,
          },
          practiceId: item.id || 0,
          assignmentTypeId: item.locationNumber===1?1:2,
          status: "Approved",
          sourceSystem: "SQCN",
        };
        contactInfo.push(localObject);
       // if (item.locationNumber === 1) {
          contactWithLocation.push({ ...localObject, location: item });
       // }
      });
      let localLocation = [...locationPayload, ...locationData];
      setLocationPayload(localLocation);
      let localContactInfo = [...contactInformationData, ...contactInfo];

      setContactInformationData(localContactInfo);

      setViewProviderIdModal(false);

      setUpdatedProviderList([...updatedProviderList, ...contactWithLocation]);

      setCreatNpi(null);

      // setHideSubmit(true);
    },
  });

  const handleCheckYes = (e, itemId) => {
    // const updatedData = locationData.map((item) => {
    //   if (item.localId === itemId) {
    //     return {
    //       ...item,
    //       isProviderTrue: e.target.checked,
    //       isProviderFalse: !e.target.checked,
    //       termDate: null,
    //       assignmentTypeId: item?.isDefaultId === true ? 1 : 2,
    //     };
    //   }
    //   return item;
    // });
    // setLocationData(updatedData);
    // setProviderEdit({ ...providerEdit, practiceAssignment: updatedData });
    const isProviderTrueSelected = e.target.checked;

    const updatedData = locationData?.map((item) => {
      let localId = item.localId;

      if (localId === itemId) {
        // Update the selected item
        return {
          ...item,
          isProviderTrue: isProviderTrueSelected,
          isProviderFalse: !isProviderTrueSelected,
          termDate: null,
          assignmentTypeId: isProviderTrueSelected ? 2 : 1,
          assignmentType: {
            ...item.assignmentType,
            id: isProviderTrueSelected ? 2 : 1,
          },
          // Ensure isPrimarySelect is false if toggling isProviderTrue
          isPrimarySelect: isProviderTrueSelected ? false : item.isPrimarySelect,
        };
      }

      // Ensure only one isPrimarySelect for isProviderTrue and isProviderFalse
      if (isProviderTrueSelected && item.isProviderTrue) {
        return {
          ...item,
          isPrimarySelect: false,
        };
      }

      if (!isProviderTrueSelected && item.isProviderFalse) {
        return {
          ...item,
          isPrimarySelect: false,
        };
      }

      return item;
    });
    setProviderEdit({ ...providerEdit, practiceAssignment: updatedData });
  };
  const handleCheckNo = (e, itemId) => {
    const updatedData = locationData.map((item) => {
      if (item.localId === itemId) {
        return {
          ...item,
          isProviderTrue: !e.target.checked,
          isProviderFalse: e.target.checked,
          assignmentTypeId: 2,
          assignmentType: {
            ...item.assignmentType,
            id: 2,
          },
        };
      }
      return item;
    });
    setLocationData(updatedData);
    setProviderEdit({ ...providerEdit, practiceAssignment: updatedData });
  };
  const handleRadioSelection = (pid, item, isSelect) => {
    const updatedData = locationData?.map((item) => {
      if (item?.isDefaultId && isSelect) {
        return {
          ...item,
          isProviderTrue: true,
          isProviderFalse: false,
          assignmentTypeId: item?.localId === pid ? 1 : 2,
          assignmentType: {
            ...item.assignmentType,
            id: item?.localId === pid ? 1 : 2,
          },
        };
      } else if (!item?.isDefaultId) {
        return {
          ...item,
          isProviderTrue: item?.localId === pid ? true : false,
          isProviderFalse: item?.localId === pid ? false : true,
          termDate: null,
          assignmentTypeId: item?.localId === pid ? 1 : 2,
          assignmentType: {
            ...item.assignmentType,
            id: item?.localId === pid ? 1 : 2,
          },
        };
      } else if (item.isDefaultId) {
        return {
          ...item,
          isProviderTrue: true,
          isProviderFalse: false,
          termDate: null,
          assignmentTypeId: item?.localId === pid ? 1 : 2,
          assignmentType: {
            ...item.assignmentType,
            id: item?.localId === pid ? 1 : 2,
          },
        };
      }
      return {
        ...item,
        assignmentTypeId: item?.localId === pid ? 1 : 2,
        ["assignmentType.id"]: item?.localId === pid ? 1 : 2,
      };
    });
    setLocationData(updatedData);
    setProviderEdit({ ...providerEdit, practiceAssignment: updatedData });
    setPrimaryPracticeId(pid);
  };

  const startDateFn = (date, itemId) => {
    const selectedDate = convertLocalToUTCDate(date);
    const isoDateString = formatDateByTimeZone(selectedDate);
    const updatedData = locationData?.map((item) => {
      if (item.localId === itemId) {
       // console.log("item", item.id);
        return { ...item, startDate: isoDateString };
      }
      return item;
    });
    setLocationData(updatedData);
    setProviderEdit({ ...providerEdit, practiceAssignment: updatedData });
  };
  const endDateFn = (date, itemId) => {
    const selectedDate = convertLocalToUTCDate(date);
    const isoDateString = formatDateByTimeZone(selectedDate);
    const updatedData = locationData?.map((item) => {
      if (item.localId === itemId) {
        return { ...item, termDate: isoDateString };
      }
      return item;
    });
    setLocationData(updatedData);
    setProviderEdit({ ...providerEdit, practiceAssignment: updatedData });
  };





  const updateEndDateNotes = (notes, itemId) => {

    const updatedData = locationData?.map((item) => {
      if (item.localId === itemId) {
        return { ...item, notesRegardingTermdatesforRoles: notes };
      }
      return item;
    });
    setLocationData(updatedData);
    setProviderEdit({ ...providerEdit, practiceAssignment: updatedData });
  };
  // const newhandleSelectPrefix = (e) => {
  //   const value = { ...providerPrefix, prefixId: e.target.value };
  //   setProviderPrefix(value);
  // };
  const selectedSpecialtyIdfn = (id, name, data = []) => {
    console.log("spltyId", id, name, data);
    const fName = data?.filter(
      (item) =>
        item?.specialty?.specialtyName?.toLowerCase() === name?.toLowerCase()
    );
    if (fName.length > 0) {
      setNewSpecialty(false);
    } else {
      setNewSpecialty(true);
    }
    setSltdSpltyId(id);
    setSpltyName(name);
  };
  //   const handleClickStorage = () => {
  //     localStorage.removeItem("tab");
  //   };
  const handleSearchChange = (e) => {
    const input = e.target.value;
    setSearchInput(input);
  };

  const handleSearchAddressChange = (e) => {
    const input = e.target.value;
    setSearchAddress(input);
  };

  const handleSearchStartDateChange = (e) => {
    const input = e.target.value;
    setSearchStartDate(input);
  };

  const handleSearchEndDateChange = (e) => {
    const input = e.target.value;
    setSearchEndDate(input);
  };

  const createSearchPattern = (input) => {
    const sanitizedInput = input.replace(/\s/g, "").toLowerCase();
    return new RegExp(sanitizedInput, "i");
  };

  const { data: masterData } = useFetch(
    "/api/v1/practices/GetPracticeMasterData"
  );
  const [data1, setData] = useState(null);

  useEffect(() => {
    if (masterData) {
      setData(masterData);
    }
    console.log(masterData, "masterData");
  }, [masterData]);

  const [showData, setShowData] = useState([]);
  // const [contractedId, setContractedId]= useState(null)

  useEffect(() => {
    const childrens =
      data1?.specialities?.length > 0 &&
      data1?.specialities?.map((item) => item);
    setShowData(childrens);
  }, [data1]);

  const filterData = (item) => {
    const searchLocationNamePattern = createSearchPattern(searchInput);
    const searchAddressPattern = createSearchPattern(searchAddress);
    const searchStartDatePattern = createSearchPattern(searchStartDate);
    const searchEndDatePattern = createSearchPattern(searchEndDate);

    const locationMatches = item?.practice?.location?.some((location) => {
      const locationName = location?.locationName
        ?.toLowerCase()
        .replace(/\s/g, "");
      const address = `${location?.street1 || ""} ${location?.street2 || ""} ${
        location?.city || ""
      } ${location?.state || ""} ${location?.zipCode || ""}`
        .toLowerCase()
        .replace(/\s/g, "");
      const startDate = item?.startDate
        ? moment(item.startDate)
            .format("MM/DD/YYYY")
            ?.toLowerCase()
            .replace(/\s/g, "")
        : "";
      const endDate = item?.termDate
        ? moment(item?.termDate)
            .format("MM/DD/YYYY")
            ?.toLowerCase()
            .replace(/\s/g, "")
        : "";

      return (
        searchLocationNamePattern.test(locationName) &&
        searchAddressPattern.test(address) &&
        searchStartDatePattern.test(startDate) &&
        searchEndDatePattern.test(endDate)
      );
    });

    return locationMatches;
  };

  useEffect(() => {
    const newFilteredData =
      providerEdit?.practiceAssignment?.filter(filterData);
    setFilteredAllData(newFilteredData);
  }, [
    searchInput,
    searchAddress,
    searchStartDate,
    searchEndDate,
    providerEdit?.practiceAssignment,
  ]);

  const toggleSortOrder = () => {
    setSortOrder(sortOrder === "asc" ? "desc" : "asc");
  };

  const sortDataByStartDate = () => {
    const sortedData = [...filteredAllData];
    sortedData.sort((a, b) => {
      const order = sortOrder === "asc" ? 1 : -1;
      return order * moment(a.startDate).diff(moment(b.startDate));
    });
    setFilteredAllData(sortedData);
    toggleSortOrder();
  };

  const sortDataByEndDate = () => {
    const sortedData = [...filteredAllData];
    sortedData.sort((a, b) => {
      const order = sortOrder === "asc" ? 1 : -1;
      return order * moment(a.termDate).diff(moment(b.termDate));
    });
    setFilteredAllData(sortedData);
    toggleSortOrder();
  };
  //   const primaryPending = filteredAllData?.filter(
  //     (item) => item?.status === "Pending" && item?.assignmentTypeId === 1
  //   );

  const [locationData, setLocationData] = useState("");
  const clickHandler = (locations) => {
    const addedLocations = [...locationData,...locations] || [];

addedLocations.forEach((item, i) => {
  item.localId = i + 1;
  item.newLocation=true;
  item.isDefaultID= item?.locationNumber === 1 ? true : false;
});
    setLocationData(addedLocations);
  };

  useEffect(() => {
    let result = [];
    if (
      allLocationData &&
      allLocationData?.length > 0 &&
      filteredAllData?.length > 0
    ) {
      result = allLocationData?.filter(
        (dataItem) =>
          !filteredAllData[0]?.practice?.location?.some(
            (locationItem) => locationItem.id === dataItem.id
          )
      );
      setAddLocationListData(result);
    }
  }, [filteredAllData, addLocationList]);

  console.log(addLocationList, filteredAllData, "filteredAllData");

  return (
    <div>
      <Container className="mt-40">
        {success && (
          <div>
            <Alert variant="success" data-testid="successProvider">
              <img
                src={updatedIcon}
                alt="Updated Icon"
                className="updated-icon"
              />
              Provider information create successfully
              <button
                onClick={() => setSuccess(false)}
                className="close-icon-button"
                data-testid="providerProfileupdatedclose"
              >
                <img
                  src={closeIcon}
                  alt="Updated Icon"
                  className="updated-icon"
                />
              </button>
            </Alert>
          </div>
        )}
        {!hideData && (
          <div className="edit-provider">
            <Form onSubmit={formik.handleSubmit}>
              <Row>
                <Col md={2} xs={12}>
                  <div className="provider-profile">
                    <div
                      className="firstletter justify-content-center  d-flex align-items-center"
                      data-testid="providerNamefirstletters"
                    >
                      {firstLetters}
                    </div>
                  </div>
                </Col>
                <Col md={10} xs={12}>
                  <div className="main-block create_provider">
                    <div className="block">
                      <Form.Label>
                        Providers Effective Date with SQCN111
                      </Form.Label>
                      <div className="input-group search-container-date">
                        <DatePicker
                          dateFormat="MM/dd/yyyy"
                          selected={effectiveDate}
                          onChange={(date) => {
                            // handleChange({
                            //   target: { name: "termDate", value: date },
                            // })

                            setEffectiveDate(date);
                          }}
                          placeholderText="--"
                          data-testid="editproviderStartDate"
                          className="nb-input width-full"
                          value={effectiveDate}
                          minDate={new Date()}
                        />

                        <button
                          type="button"
                          className="search-button right cursor-auto"
                        >
                          <img src={DatePickerIcon} alt="DatePicker Icon" />
                        </button>
                      </div>
                    </div>
                    <div className="block">
                      <Form.Label>{labels.NPI}</Form.Label>

                      <Form.Control
                        type="tel"
                        maxlength={10}
                        placeholder="---"
                        name="npi"
                        className={
                          formik.touched.npi && formik.errors.npi
                            ? "error-field nb-input"
                            : "nb-input"
                        }
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        value={
                          formik.values.npi
                            ? formik.values.npi
                            : localStorage.getItem("creatNpi")
                        }
                        onKeyDown={(e) => {
                          e.key === "Enter" && e.preventDefault();
                        }}
                        data-testid="providerNpi"
                      />
                      {formik.touched.npi && formik.errors.npi ? (
                        <div
                          className="form-error"
                          data-testid="providerNpiError"
                        >
                          {formik.errors.npi}
                        </div>
                      ) : null}
                    </div>
                    <div className="block">
                      <Form.Label>{labels.MDOFFICE_ID}</Form.Label>
                      <Form.Control
                        type="text"
                        placeholder="---"
                        name="mdofficeId"
                        className={
                          formik.touched.mdofficeId && formik.errors.mdofficeId
                            ? "error-field nb-input"
                            : "nb-input"
                        }
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        value={formik.values.mdofficeId}
                        onKeyDown={(e) => {
                          e.key === "Enter" && e.preventDefault();
                        }}
                        data-testid="providerMDofficeId"
                      />
                      {formik.touched.mdofficeId && formik.errors.mdofficeId ? (
                        <div
                          className="form-error"
                          data-testid="providerMDofficeIdError"
                        >
                          {formik.errors.mdofficeId}
                        </div>
                      ) : null}
                    </div>
                    <div className="block">
                      <Form.Label>
                        {labels.PROVIDER_NAME_BEFORE_EDITING}
                      </Form.Label>
                      <Form.Control
                        type="text"
                        placeholder="---"
                        name="providersNameBeforeEditing"
                        className={
                          formik.touched.providersNameBeforeEditing &&
                          formik.errors.providersNameBeforeEditing
                            ? "error-field nb-input"
                            : "nb-input"
                        }
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        value={formik.values.providersNameBeforeEditing}
                        onKeyDown={(e) => {
                          e.key === "Enter" && e.preventDefault();
                        }}
                        data-testid="providersNameBeforeEditing"
                      />
                    </div>
                  </div>
                  <div className="main-block create_provider_select">
                    {/* <div className="block">
                      <div className="title mt-2">{labels.PREFIX}</div>
                      <div className="title-dropdown">
                        <div
                          className="title-change"
                          data-testid="locationType"
                        >
                          {providerPrefix?.prefixId == 1 && <div>---</div>}
                          {providerPrefix?.prefixId == 2 && <div>Mr</div>}
                          {providerPrefix?.prefixId == 3 && <div>Ms</div>}
                          {providerPrefix?.prefixId == 4 && <div>Dr</div>}
                          <span className="locationtypeicon">
                            <img src={dropIcon} alt="dropdown icon" />
                          </span>
                        </div>
                        <div className="title-list-block">
                          <ul className="title-list">
                            <li className="titles" data-testid="Type">
                              <button
                                type="button"
                                name="prefixType"
                                className={
                                  providerPrefix.prefixId == 1
                                    ? "selected-primary"
                                    : ""
                                }
                                onClick={(e) => newhandleSelectPrefix(e)}
                                value="1"
                                data-testid="TypeMr"
                              >
                                ---
                              </button>
                            </li>
                            <li className="titles" data-testid="Type">
                              <button
                                type="button"
                                name="prefixType"
                                className={
                                  providerPrefix.prefixId == 2
                                    ? "selected-primary"
                                    : ""
                                }
                                onClick={(e) => newhandleSelectPrefix(e)}
                                value="2"
                                data-testid="TypeMr"
                              >
                                Mr
                              </button>
                            </li>
                            <li className="titles" data-testid="Type">
                              <button
                                type="button"
                                name="prefixType"
                                className={
                                  providerPrefix.prefixId == 3
                                    ? "selected-primary"
                                    : ""
                                }
                                onClick={(e) => newhandleSelectPrefix(e)}
                                value="3"
                                data-testid="TypeMs"
                              >
                                Ms
                              </button>
                            </li>
                            <li className="titles" data-testid="Type">
                              <button
                                type="button"
                                name="prefixType"
                                className={
                                  providerPrefix.prefixId == 4
                                    ? "selected-primary"
                                    : ""
                                }
                                onClick={(e) => newhandleSelectPrefix(e)}
                                value="4"
                                data-testid="TypeDr"
                              >
                                Dr
                              </button>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div> */}

                    <div className="block">
                      <div className="title mt-2">{labels.PREFIX}</div>

                      <Form.Select
                        size="md"
                        placeholder="---"
                        id="prefix"
                        autoComplete="off"
                        value={providerPrefixName}
                        defaultValue={providerPrefixName}
                        className="nb-select"
                        name="prefix"
                        // onChange={handleChange}

                        onChange={(e) => {
                          handleInputChange(e);

                          let id =
                            e.target[e.target.selectedIndex].getAttribute(
                              "data-prefixId"
                            );

                          handleIdChange("prefixId", id);
                        }}
                      >
                        <option value={providerPrefixName}>
                          {providerPrefixName}
                        </option>
                        {prefixData.map((prefixItem, index) => (
                          <option
                            key={prefixItem.prefixName + index}
                            value={prefixItem.prefixName}
                            data-prefixId={prefixItem.id}
                          >
                            {prefixItem.prefixName}
                          </option>
                        ))}
                      </Form.Select>
                    </div>

                    <div className="block">
                      <Form.Label>{labels.FIRST_NAME}</Form.Label>
                      <Form.Control
                        type="text"
                        placeholder="---"
                        className={
                          formik.touched.firstName && formik.errors.firstName
                            ? "error-field nb-input"
                            : "nb-input"
                        }
                        name="firstName"
                        autoComplete="off"
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        value={formik.values.firstName}
                        onKeyDown={(e) => {
                          e.key === "Enter" && e.preventDefault();
                        }}
                        data-testid="providerFirstName"
                      />
                      {formik.touched.firstName && formik.errors.firstName ? (
                        <div
                          className="form-error"
                          data-testid="providerFirstNameError"
                        >
                          {formik.errors.firstName}
                        </div>
                      ) : null}
                    </div>
                    <div className="block">
                      <Form.Label>{labels.MIDDLE_INTITIAL}</Form.Label>
                      <Form.Control
                        type="text"
                        placeholder="---"
                        name="middleName"
                        autoComplete="off"
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        value={formik.values.middleName}
                        onKeyDown={(e) => {
                          e.key === "Enter" && e.preventDefault();
                        }}
                        data-testid="providerMiddleName"
                        className={
                          formik.touched.middleName && formik.errors.middleName
                            ? "error-field nb-input"
                            : "nb-input"
                        }
                      />
                      {formik.touched.middleName && formik.errors.middleName ? (
                        <div
                          className="form-error"
                          data-testid="providerMiddleNameError"
                        >
                          {formik.errors.middleName}
                        </div>
                      ) : null}
                    </div>
                    <div className="block">
                      <Form.Label>{labels.LAST_NAME}</Form.Label>
                      <Form.Control
                        type="text"
                        placeholder="---"
                        name="lastName"
                        className={
                          formik.touched.lastName && formik.errors.lastName
                            ? "error-field nb-input"
                            : "nb-input"
                        }
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        value={formik.values.lastName}
                        onKeyDown={(e) => {
                          e.key === "Enter" && e.preventDefault();
                        }}
                        data-testid="providerLastName"
                      />
                      {formik.touched.lastName && formik.errors.lastName ? (
                        <div
                          className="form-error"
                          data-testid="providerLastNameError"
                        >
                          {formik.errors.lastName}
                        </div>
                      ) : null}
                    </div>
                    <div className="block">
                      <Form.Label>{labels.SUFFIX}</Form.Label>
                      <div className="title-dropdown">
                        <div className="title-change" data-testid="titleName">
                          {selectedSuffix ? selectedSuffix : "---"}
                          <span>
                            <img src={dropIcon} alt="dropdown icon" />
                          </span>
                        </div>
                        <div className="title-list-block">
                          <ul className="title-list">
                            {allSuffixData.map((suffix, index) => (
                              <li
                                className="titles"
                                key={index}
                                value={selectedSuffix}
                              >
                                <button
                                  type="button"
                                  data-testid={`suffix-button-${index}`}
                                  onClick={() => {
                                    setSelectedSuffix(suffix);
                                    console.log(
                                      selectedSuffix,
                                      "selectedSuffix"
                                    );

                                    setProviderEdit((prev) => {
                                      let prevState = prev;
                                      prevState.suffix = suffix;
                                      return prevState;
                                    });
                                  }}
                                >
                                  {suffix}
                                </button>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </div>

                    <div className="block">
                      <Form.Label>{labels.TITLE}</Form.Label>
                      <Form.Select
                        size="md"
                        id="title"
                        autoComplete="off"
                        name="title"
                        value={selectedTitle}
                        defaultValue={selectedTitle}
                        className="nb-select"
                        onChange={(e) => {
                          // handleInputChange(e, i);

                          setSelectedTitle(e.target.value);
                          let id =
                            e.target[e.target.selectedIndex].getAttribute(
                              "data-title"
                            );
                          if (prefix_mapTitles.includes(id)) {
                            handlePrefixChange(id);
                          }
                        }}
                      >
                        <option value={selectedTitle}>{selectedTitle}</option>
                        {data.map((titleItem, index) => (
                          <option
                            key={titleItem.title + index}
                            value={titleItem.title}
                            data-title={titleItem.id}
                          >
                            {titleItem.title}
                          </option>
                        ))}
                      </Form.Select>
                    </div>
                  </div>
                  <div className="main-block create_provider_select">
                    <div className="block">
                      <Form.Label>{labels.BOARD_SPECIALITY}</Form.Label>
                      <EditSpecialtyPage
                        specialtyDetailsByspecialtype={
                          specialtyDetailsByspecialtype
                        }
                        selectedSpecialtyIdfn={selectedSpecialtyIdfn}
                      />
                      {!spltyName && (
                        <p className="form-error">
                          Board Specialty is required
                        </p>
                      )}
                    </div>
                    <div className="block">
                      <Form.Label>{labels.CONTRACTED_SPECIALITY}</Form.Label>

                      <Form.Select
                        size="sm"
                        id={"prefixType"}
                        autoComplete="off"
                        value={formik.values.contractedSpecialtyId}
                        defaultValue={formik.values.contractedSpecialtyId}
                        className="nb-input"
                        placeholder="---"
                        onChange={(e) => {
                          formik.handleChange({
                            target: {
                              name: "contractedSpecialtyName",
                              value: e.value,
                            },
                          });
                          let contractedSpecialtyId = e.target[
                            e.target.selectedIndex
                          ].getAttribute("data-contractedSpecialtyId");
                          formik.handleChange({
                            target: {
                              name: "contractedSpecialtyId",
                              value: contractedSpecialtyId,
                            },
                          });
                        }}
                      >
                        <option value={""}>{"---"}</option>
                        {showData.length > 0 &&
                          showData?.map((item) => (
                            <option
                              key={item.id}
                              data-contractedSpecialtyId={item.id}
                              value={item.id}
                            >
                              {item.specialtyName}
                            </option>
                          ))}
                      </Form.Select>
                    </div>
                    <div className="block">
                      <Form.Label>{labels.PREFERED_EMAIL_ADDRESS}</Form.Label>
                      <Form.Control
                        type="email"
                        placeholder="---"
                        name="preferredEmailAddress"
                        autoComplete="off"
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        value={formik.values.preferredEmailAddress}
                        onKeyDown={(e) => {
                          e.key === "Enter" && e.preventDefault();
                        }}
                        data-testid="providerPreferredEmailAddress"
                        className={
                          formik.touched.preferredEmailAddress &&
                          formik.errors.preferredEmailAddress
                            ? "error-field nb-input"
                            : "nb-input"
                        }
                      />
                      {formik.touched.preferredEmailAddress &&
                      formik.errors.preferredEmailAddress ? (
                        <div
                          className="form-error"
                          data-testid="providerPreferredEmailAddressError"
                        >
                          {formik.errors.preferredEmailAddress}
                        </div>
                      ) : null}
                    </div>
                    <div className="block">
                      <Form.Label>{labels.SENTARA_EMAIL_ADDRESS}</Form.Label>
                      <Form.Control
                        type="email"
                        placeholder="---"
                        name="sentaraEmailAddress"
                        autoComplete="off"
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        value={formik.values.sentaraEmailAddress}
                        onKeyDown={(e) => {
                          e.key === "Enter" && e.preventDefault();
                        }}
                        data-testid="providersentaraEmailAddress"
                        className={
                          formik.touched.sentaraEmailAddress &&
                          formik.errors.sentaraEmailAddress
                            ? "error-field nb-input"
                            : "nb-input"
                        }
                      />
                      {formik.touched.sentaraEmailAddress &&
                      formik.errors.sentaraEmailAddress ? (
                        <div
                          className="form-error"
                          data-testid="providersentaraEmailAddressError"
                        >
                          {formik.errors.sentaraEmailAddress}
                        </div>
                      ) : null}
                    </div>
                  </div>
                </Col>
              </Row>
              <Row>
                <Col md={12} xs={12}>
                  <div
                    className="location-banner provider-loc"
                    data-testid="locationBanner"
                  >
                    <Row>
                      <Col
                        md={8}
                        xs={12}
                        className="practice-loc-title"
                        data-testid="practicelocationTitle"
                      >
                        <h4>Practice Assignments</h4>
                      </Col>
                      <Col md={4} xs={12} className="ta-right">
                        <Button
                          variant="primary"
                          onClick={() => setModalShow(true)}
                          className="add-location"
                          data-testid="AddLocationbutton"
                        >
                          {/* <span>
                            <img src={addIcon} alt="add icon" />
                          </span> */}
                          Add Practice Assignments
                        </Button>
                        {modalShow && (
                          <AddLocationModalPageAdmin
                            data-testid="LocationModel"
                            show={modalShow}
                            onHide={() => setModalShow(false)}
                            clickHandler={clickHandler}
                            practiceManagerId={practiceManagerId}
                            addLocationList={allLocationData}
                            id="0"
                          />
                        )}
                      </Col>
                    </Row>
                  </div>
                  <div className="provider-location-table">
                    <Table data-testid="providerLocationtable">
                      <thead>
                        <tr>
                          <th width="18%">Location Number - Name</th>
                          <th width="22%">Address</th>
                          <th className="phone-head5" width="20%">
                            Provider at Location
                          </th>
                          <th className="phone-head4">Is Primary?</th>
                          <th className="phone-head6">
                            <span className="date_text">Start Date</span>
                            <button
                              className="sort_icon_arrow"
                              type="button"
                              onClick={sortDataByStartDate}
                            >
                              <img src={sortIcon} alt="Sort Icon" />
                            </button>
                          </th>
                          <th className="phone-head6">
                            <span className="date_text">End Date </span>
                            <button
                              className="sort_icon_arrow"
                              type="button"
                              onClick={sortDataByEndDate}
                            >
                              <img src={sortIcon} alt="Sort Icon" />
                            </button>
                          </th>
                          <th width="22%">Notes Regarding Term Dates</th>
                        </tr>
                      </thead>
                      <tbody data-testid="ProviderData">
                        <tr>
                          <td className="search_column">
                            <Form.Group
                              className="search-npi"
                              controlId="formGroupEmail"
                            >
                              <Form.Control
                                type="text"
                                name="location"
                                placeholder="Search"
                                autoComplete="off"
                                className="search-input new"
                                value={searchInput}
                                onChange={handleSearchChange}
                                data-testid="LocationName"
                              />
                            </Form.Group>
                          </td>
                          <td className="search_column">
                            <Form.Group
                              className="search-npi"
                              controlId="formGroupEmail"
                            >
                              <Form.Control
                                type="text"
                                name="location"
                                placeholder="Search"
                                autoComplete="off"
                                className="search-input new"
                                value={searchAddress}
                                onChange={handleSearchAddressChange}
                                data-testid="LocationName"
                              />
                            </Form.Group>
                          </td>
                          <td className="search_column"></td>
                          <td className="search_column"></td>
                          <td className="search_column">
                            <Form.Group
                              className="search-npi"
                              controlId="formGroupEmail"
                            >
                              <Form.Control
                                type="text"
                                name="location"
                                placeholder="Search"
                                autoComplete="off"
                                className="search-input new"
                                value={searchStartDate}
                                onChange={handleSearchStartDateChange}
                                data-testid="LocationName"
                              />
                            </Form.Group>
                          </td>
                          <td className="search_column1">
                            <Form.Group
                              className="search-npi"
                              controlId="formGroupEmail"
                            >
                              <Form.Control
                                type="text"
                                name="location"
                                placeholder="Search"
                                autoComplete="off"
                                className="search-input new"
                                value={searchEndDate}
                                onChange={handleSearchEndDateChange}
                                data-testid="LocationName"
                              />
                            </Form.Group>
                          </td>
                          <td className="search_column"></td>
                        </tr>

                        <React.Fragment>
                          {Array.isArray(locationData) &&
                            locationData?.map((locationItem, index) => (
                              <tr key={locationItem.id}>
                                <td
                                  className={
                                    locationItem?.locationNumber === 1
                                      ? "Primary1"
                                      : "Secondary1"
                                  }
                                >
                                  {locationItem?.locationNumber}
                                  &nbsp;-&nbsp;
                                  {locationItem?.locationName}
                                </td>
                                <td
                                  className={
                                    locationItem?.locationNumber === 1
                                      ? "Primary1"
                                      : "Secondary1"
                                  }
                                >
                                  {`${locationItem?.street1} ${
                                    locationItem?.street2
                                      ? locationItem?.street2
                                      : ""
                                  }, ${locationItem?.city}, ${
                                    locationItem?.state
                                  } ${locationItem?.zipCode}`}
                                </td>
                                <td
                                  className={
                                    locationItem?.locationNumber === 1
                                      ? "Primary1 text-center"
                                      : "Secondary1 text-center"
                                  }
                                >
                                  <div className="info">
                                    <Form.Check
                                      inline
                                      type="radio"
                                      disabled={
                                        locationItem?.locationNumber !== 1
                                      }
                                      label="Yes"
                                      name={`${"providerAtLocation"[index]}`}
                                      data-testid="providerAtLocationYes"
                                      value={locationItem?.isProviderTrue}
                                      checked={locationItem?.isProviderTrue}
                                      onChange={(e) =>
                                        handleCheckYes(e, locationItem?.localId)
                                      }
                                    />
                                    <Form.Check
                                      inline
                                      type="radio"
                                      disabled={
                                        locationItem?.locationNumber !== 1
                                      }
                                      label="No"
                                      data-testid="providerAtLocationNo"
                                      name={`${"providerAtLocation"[index]}`}
                                      value={locationItem?.isProviderFalse}
                                      checked={locationItem?.isProviderFalse}
                                      onChange={(e) =>
                                        handleCheckNo(e, locationItem?.localId)
                                      }
                                    />
                                  </div>
                                </td>
                                {locationItem?.locationNumber === 1 ? (
                                  <td
                                    className={
                                      locationItem?.locationNumber === 1
                                        ? "Primary1 text-center"
                                        : "Secondary1 text-center"
                                    }
                                  >
                                    <div className="info">
                                      <Form.Check
                                        inline
                                        type="radio"
                                        data-testid="providerPrimary"
                                        name={`${"providerPrimary"[index]}`}
                                        value={
                                          locationItem?.assignmentTypeId === 1
                                        }
                                        checked={
                                          locationItem?.assignmentTypeId === 1
                                        }
                                        onChange={() =>
                                          handleRadioSelection(
                                            locationItem?.localId,
                                            locationItem,
                                            locationItem?.isDefaultId
                                          )
                                        }
                                      />
                                    </div>
                                  </td>
                                ) : (
                                  <td
                                    className={
                                      locationItem?.locationNumber === 1
                                        ? "Primary1 text-center"
                                        : "Secondary1 text-center"
                                    }
                                  >
                                    {/* You may add content here if needed */}
                                  </td>
                                )}

                                {locationItem?.locationNumber === 1 ? (
                                  <td
                                    className={
                                      locationItem?.locationNumber === 1
                                        ? "Primary1"
                                        : "Secondary1 text-center"
                                    }
                                  >
                                    <div
                                      className="info"
                                      data-testid="editstartDateInput"
                                    >
                                      <DatePicker
                                        dateFormat="MM/dd/yyyy"
                                        selected={locationItem?.startDate}
                                        onChange={(date) =>
                                          startDateFn(date, locationItem.localId)
                                        }
                                        placeholderText="MM/DD/YYYY"
                                        data-testid="editproviderStartDate"
                                      />
                                    </div>
                                  </td>

                                  
                                ) : (
                                  <td
                                    className={
                                      locationItem?.locationNumber === 1
                                        ? "Primary1"
                                        : "Secondary1"
                                    }
                                  >
                                    {locationItem?.startDate
                                      ? moment(locationItem?.startDate).format(
                                          "MM/DD/YYYY"
                                        )
                                      : "--"}
                                  </td>
                                )}
                                {locationItem?.locationNumber === 1 ? (
                                  <>
                                  <td
                                    className={
                                      locationItem?.locationNumber === 1
                                        ? "Primary1"
                                        : "Secondary1"
                                    }
                                  >
                                    <div
                                      className="info"
                                      data-testid="editendDateInput"
                                    >
                                      <DatePicker
                                        disabled={locationItem?.isProviderTrue}
                                        dateFormat="MM/dd/yyyy"
                                        data-testid="editproviderEndDate"
                                        selected={locationItem?.termDate}
                                        placeholderText="MM/DD/YYYY"
                                        onChange={(date) =>
                                          endDateFn(date, locationItem.localId)
                                        }
                                        required
                                        // minDate={formattedStartDate}
                                      />
                                    </div>
                                  </td>

<td  className={
  locationItem?.locationNumber === 1
    ? "Primary1"
    : "Secondary1"
}>   <div
className="info"
data-testid="editendDateInput"
><Form.Control
type="text"
placeholder="--"
id="notesRegardingTermdatesforLocation"
autoComplete="off"
className="nb-input"
value={locationItem.notesRegardingTermdatesforRoles}
onChange={(e) =>{
updateEndDateNotes(e.target.value, locationItem.localId)

}}

disabled={locationItem?.isProviderTrue}
// isInvalid={!!errors.street1}
/>
</div>
</td></>
                                ) : (
                                  
                                  <td
                                    className={
                                      locationItem?.locationNumber === 1
                                        ? "Primary1"
                                        : "Secondary1"
                                    }
                                  >
                                    {locationItem?.termDate
                                      ? moment(locationItem?.termDate).format(
                                          "MM/DD/YYYY"
                                        )
                                      : "--"}
                                  </td>

                                )}
                              </tr>
                            ))}
                        </React.Fragment>
                      </tbody>
                    </Table>
                  </div>
                  <div className="add-location-footer">
                    {errorMessage && (
                      <p className="Error-message">{errorMessage}</p>
                    )}
                    <div className="d-flex justify-content-end">
                      <button
                        className="blue-btn"
                        type="submit"
                        disabled={
                          (!spltyName || isLoading) &&
                          locationData?.length === 0
                        }
                        data-testid="EditConfirmButton"
                      >
                        {isLoading ? "Saving..." : "Save"}
                      </button>
                    </div>
                  </div>
                </Col>
              </Row>
            </Form>
          </div>
        )}
        {hideData && (
          <CreateNewProviderAdminNew
            practiceManagerId={decodeToken?.id || practiceManagerId}
            providerSummary={providerSummary}
            selectedPracticeId={selectedPracticeId}
            practiceTitle={practiceTitle}
            personRoleName={personRoleName}
          />
        )}
      </Container>
    </div>
  );
};

export default CreateNewProviderAdminNew;
