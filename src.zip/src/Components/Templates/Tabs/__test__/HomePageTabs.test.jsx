import { cleanup, render, screen } from "@testing-library/react";
// import renderer from "react-test-renderer";
import HomePageTabs from "../HomePageTabs";

afterEach(cleanup);

describe("Test the Home page Tabs Component", () => {
  test("renders Home Page tab in the document", () => {
    render(<HomePageTabs />);
    const practiceTab = screen.getByRole("button", {
      name: /practice information/i,
    });
    const contactTab = screen.getByRole("button", {
      name: /contact information/i,
    });
    const providerTab = screen.getByRole("button", {
      name: /provider list/i,
    });
    expect(practiceTab).toBeInTheDocument();
    expect(contactTab).toBeInTheDocument();
    expect(providerTab).toBeInTheDocument();
  });
});
