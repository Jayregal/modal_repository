import { useParams } from "react-router-dom";

import jwt_decode from "jwt-decode";
import cookies from "js-cookie";
import CreateNewProviderAdminNew from "../ProviderList/CreateNewProviderAdmin";

const CreateNewProviderAdminNeweAdmin = ({
  practiceTitle,
  selectedPracticeId,
  practiceManagerId,
  providerId,
  personRoleName,
  locationPayload,
  setLocationPayload,
  setContactInformationData,
  contactInformationData,
  setViewProviderIdModal,
  setUpdatedProviderList,
  updatedProviderList,
  setCreatNpi,
}) => {
  const { id } = useParams();
  const token = cookies.get("access");
  const decodeToken = jwt_decode(token);
  console.log(
    "editt",
    practiceTitle,
    selectedPracticeId,
    practiceManagerId,
    id
  );
  return (
    <>
      <CreateNewProviderAdminNew
        practiceManagerId={decodeToken?.id || practiceManagerId}
        id={providerId}
        selectedPracticeId={selectedPracticeId}
        practiceTitle={practiceTitle}
        personRoleName={personRoleName}
        locationPayload={locationPayload}
        setLocationPayload={setLocationPayload}
        setContactInformationData={setContactInformationData}
        contactInformationData={contactInformationData}
        setViewProviderIdModal={setViewProviderIdModal}
        setUpdatedProviderList={setUpdatedProviderList}
        updatedProviderList={updatedProviderList}
        setCreatNpi={setCreatNpi}
      />
    </>
  );
};

export default CreateNewProviderAdminNeweAdmin;
