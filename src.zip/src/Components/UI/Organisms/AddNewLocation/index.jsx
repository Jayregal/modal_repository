/* eslint-disable indent */
import React from "react";
import { Form } from "react-bootstrap";
import labels from "Static/Dictionary.json";
import DatePicker from "react-datepicker";
import dropIcon from "../../../Templates/ProviderList/images/dropdownIcon.svg";

function AddNewLocation({
  newLocationData,
  index,
  handleChangeProvider,
  newStartDateFn,
  newEndDateFn,
  newHandleSelect,
}) {
  console.log("skdjflsdkf", newLocationData);
  return (
    <>
      <div className="practice-location-title">
        <h5 data-testid="locationName">
          {newLocationData?.selectedLocation?.locationName}
        </h5>
      </div>
      <div className="main-block">
        <div className="block fg-2">
          <div className="title">{labels.ADDRESS}</div>
          <div className="info" data-testid="locationAddress">
            {`${newLocationData?.selectedLocation?.street1
              } ${newLocationData?.selectedLocation?.street2
                ? newLocationData?.selectedLocation?.street2
                : ""
              }, ${newLocationData?.selectedLocation?.city}, ${newLocationData?.selectedLocation?.state
              } ${newLocationData?.selectedLocation?.zipcode}`}
          </div>

        </div>
        <div className="block">
          <div className="title">{labels.LOCATION_TYPE}</div>
          <div className="info">
            <div className="title-dropdown">
              <div className="title-change" data-testid="locationtype">
                {newLocationData?.locationtype == 1 ? (
                  <div data-testid="locationtypeprimary">Primary </div>
                ) : (
                  <div data-testid="locationtypeprimary">Alternate</div>
                )}
                <span className="locationtypeicon">
                  <img src={dropIcon} alt="dropdown icon" />
                </span>
              </div>
              <div className="title-list-block">
                <ul className="title-list">
                  <li className="titles">
                    <button
                      type="button"
                      name="locationtype"
                      data-testid="primary-location-button"
                      onClick={(e) => newHandleSelect(e, index)}
                      className={
                        newLocationData?.locationtype == 1
                          ? "selected-primary"
                          : ""
                      }
                      selected={
                        newLocationData?.locationtype === "1" && "selected"
                      }
                      value="1"
                    >
                      Primary
                    </button>
                  </li>
                  <li className="titles">
                    <button
                      type="button"
                      name="locationtype"
                      data-testid="alternate-location-button"
                      className={
                        newLocationData?.locationtype == 2
                          ? "selected-alternate"
                          : ""
                      }
                      onClick={(e) => newHandleSelect(e, index)}
                      selected={
                        newLocationData?.locationtype === "2" && "selected"
                      }
                      value="2"
                    >
                      Alternate
                    </button>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div className="block">
          <div className="title">{labels.PROVIDER_AT_LOCATIONS}</div>
          <div className="info">
            <Form.Check
              inline
              type="radio"
              label="Yes"
              data-testid="yes-provider-radio"
              value={newLocationData?.provider}
              checked={newLocationData?.provider === "yes"}
              onChange={(e) => handleChangeProvider(e, index, true)}
            />
            <Form.Check
              inline
              type="radio"
              label="No"
              data-testid="no-provider-radio"
              value={newLocationData?.provider}
              checked={newLocationData?.provider === "no"}
              onChange={(e) => handleChangeProvider(e, index, false)}
            />
          </div>
        </div>
      </div>
      <div className="main-block">
        <div className="block">
          <div className="title" data-testid="startDate">
            Start Date
          </div>
          <div className="info" data-testid="startDateInput">
            <DatePicker
              dateFormat="MM/dd/yyyy"
              placeholderText="MM/DD/YYYY"
              data-testid="startdate"
              selected={newLocationData?.startDate}
              onChange={(date) => newStartDateFn(date, index)}
            />
          </div>
        </div>
        <div className="block">
          <div
            className={`title ${newLocationData?.provider === "yes" && "disabled"
              }`}
            data-testid="endDate"
          >
            End Date
          </div>
          <div className="info" data-testid="endDateInput">
            <DatePicker
              disabled={newLocationData?.provider === "yes"}
              dateFormat="MM/dd/yyyy"
              placeholderText="MM/DD/YYYY"
              data-testid="enddate"
              selected={newLocationData?.endDate}
              onChange={(date) => newEndDateFn(date, index)}
              required
              minDate={newLocationData?.startDate}
            />
          </div>
        </div>
        <div className="block"></div>
        <div className="block"></div>
      </div>
    </>
  );
}

export default AddNewLocation;
