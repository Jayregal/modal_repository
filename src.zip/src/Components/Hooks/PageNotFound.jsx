/* eslint-disable indent */
import { Container, Row, Col } from "react-bootstrap";

const errorStyle = {
    borderRadius: "0px",
    textAlign: "center",
    padding: "80px",
    marginTop:"150px"
};

export default function PageNotFound() {
    return (
        <Container>
            <Row>
                <Col md={12}>
                    <div style={errorStyle}>
                        <h1 className="mb-0">
                            404 Error.
                        </h1>
                        <h4>Page Not Found.</h4>
                    </div>
                </Col>
            </Row>
        </Container >

    );
}
