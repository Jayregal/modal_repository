import { render } from "@testing-library/react";
import App from "./App";

describe("Test the App Component", () => {
  test("it renders without crashing", () => {
    render(<App />);
  });
});
